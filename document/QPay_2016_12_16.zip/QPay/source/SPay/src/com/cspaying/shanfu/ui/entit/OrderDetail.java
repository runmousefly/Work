package com.cspaying.shanfu.ui.entit;

public class OrderDetail {
	
	private String outRradeNo;
	private float amount;
	private String transTime;
	private String postscript;
	private String status;
	private String channel;
	
	
	public String getOutRradeNo() {
		return outRradeNo;
	}
	public void setOutRradeNo(String outRradeNo) {
		this.outRradeNo = outRradeNo;
	}
	
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getTransTime() {
		return transTime;
	}
	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}
	public String getPostscript() {
		return postscript;
	}
	public void setPostscript(String postscript) {
		this.postscript = postscript;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	
	
	
	
	
	
	



}
