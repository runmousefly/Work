package com.cspaying.shanfu.ui.entit;

public class Re_zf_pay {
	
	  private String outChannelNo;
	  private String returnMsg;
	  private String outTradeNo;
	  private String codeUrl;
	  private String resultCode;
	  private String returnCode;
	  private String sign;
	  
	  
	  
	public String getOutChannelNo() {
		return outChannelNo;
	}
	public void setOutChannelNo(String outChannelNo) {
		this.outChannelNo = outChannelNo;
	}
	
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	public String getReturnMsg() {
		return returnMsg;
	}
	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}
	
	public String getOutTradeNo() {
		return outTradeNo;
	}
	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}
	public String getCodeUrl() {
		return codeUrl;
	}
	public void setCodeUrl(String codeUrl) {
		this.codeUrl = codeUrl;
	}
	
	  

	
	
	
}
