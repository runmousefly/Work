package com.cspaying.shanfu.ui.activity;

public class ReAddCashier {
	
	private String returnCode;
	private String returnMsg;
	private String cashierName;
	private String cashierPhone;
	private String cashierNo;
	private String sign;
	private String resultCode;
	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	public String getReturnMsg() {
		return returnMsg;
	}
	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}
	public String getCashierName() {
		return cashierName;
	}
	public void setCashierName(String cashierName) {
		this.cashierName = cashierName;
	}
	public String getCashierPhone() {
		return cashierPhone;
	}
	public void setCashierPhone(String cashierPhone) {
		this.cashierPhone = cashierPhone;
	}
	public String getCashierNo() {
		return cashierNo;
	}
	public void setCashierNo(String cashierNo) {
		this.cashierNo = cashierNo;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	
	
	


}
