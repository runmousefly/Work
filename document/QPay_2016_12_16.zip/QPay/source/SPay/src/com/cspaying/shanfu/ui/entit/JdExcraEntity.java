package com.cspaying.shanfu.ui.entit;

public class JdExcraEntity {
	private String accessType;

	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}
	
	
}

