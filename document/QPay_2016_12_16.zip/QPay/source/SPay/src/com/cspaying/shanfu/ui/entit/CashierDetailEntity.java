package com.cspaying.shanfu.ui.entit;

public class CashierDetailEntity {
	
	private String cashierNo;
	private String cashierName;
	private String cashierPhone;
	private String store;
	private String startupAut;
	
	public String getCashierNo() {
		return cashierNo;
	}
	public void setCashierNo(String cashierNo) {
		this.cashierNo = cashierNo;
	}
	public String getCashierName() {
		return cashierName;
	}
	public void setCashierName(String cashierName) {
		this.cashierName = cashierName;
	}
	public String getCashierPhone() {
		return cashierPhone;
	}
	public void setCashierPhone(String cashierPhone) {
		this.cashierPhone = cashierPhone;
	}
	public String getStore() {
		return store;
	}
	public void setStore(String store) {
		this.store = store;
	}
	public String getStartupAut() {
		return startupAut;
	}
	public void setStartupAut(String startupAut) {
		this.startupAut = startupAut;
	}
	
	

}
