package com.cspaying.shanfu.common;

public class AppConfig {

}
