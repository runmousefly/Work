// BackTrackSettingDlg.h : ͷ�ļ�
//

#pragma once

#include "Co_BackTrackApi.h"
#include "afxwin.h"
#include "Co_BusProtocol_API.h"

// CBackTrackSettingDlg �Ի���
class CBackTrackSettingDlg : public CDialog
{
// ����
public:
	CBackTrackSettingDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_BACKTRACKSETTING_DIALOG };
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��
// ʵ��
protected:
	HICON m_hIcon;
	Co_BackTrackApi  m_BackTrackApi;
	static void TrackDataCallBack(int ntype,LPVOID lpdata,LPVOID lpclass);
	void DataCalllBack(int ntype,LPVOID lpdata);
	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedBtninput();
	afx_msg void OnBnClickedBtnadd();
	afx_msg void OnBnClickedBtndel();
	void   UpdateLines();
	void   DrawLines(HDC hdc);
	CEdit	m_editInput;
	CStatic m_staticname;
	CStatic m_staticid;
	TRACK_DATA m_trackdatas[MAX_LINE_NUM];
	int     m_nlastTrackNum;
	int     m_nangle;
	afx_msg void OnBnClickedBtnLeft();
	afx_msg void OnBnClickedBtnUp();
	afx_msg void OnBnClickedBtnRight();
	afx_msg void OnBnClickedBtnDown();
	CButton m_btnLeft;
	CButton m_btnRight;
	CButton m_btnUp;
	CButton m_btnDown;
	afx_msg void OnBnClickedBtnsave();
	afx_msg void OnEnSetfocusEdit1();
	Co_BusHelper*   m_bushelper;
protected:
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
public:
	CButton m_checkbtn;
};
