#ifndef __CO_BACKTRACK_API_H__
#define __CO_BACKTRACK_API_H__

#include "Co_BackTrack.h"

class Co_BackTrackApi
{
public:
	Co_BackTrackApi(){
		hInstance = NULL;
		mPFTRACKInitDataPath=NULL;
		mPFTRACKInit=NULL;
		mPFTRACKInit2 =NULL;
		mPFTRACKUnInit=NULL;
		mPFTRACKSetTrackMode=NULL;
		mPFTRACKGetTrackMode=NULL;
		mPFTRACKSetCameraCode=NULL;
		mPFTRACKGetCameraCode=NULL;
		mPFTRACKOffsetTrack=NULL;
		mPFTRACKSaveTrackSetting =NULL;
		mPFTRACKSetCameraID=NULL;
		mPFTRACKGetCameraID=NULL;
		mPFTRACKSetAngle= NULL;
		mPFTRACKinvoke=NULL;	
	}
	~Co_BackTrackApi(){
		if(hInstance){
			::FreeLibrary(hInstance);
			hInstance  = NULL;
		}
	}
	bool  Init(const wchar_t* pdllPath){
		if (hInstance||pdllPath== NULL){
			return false;
		}
		hInstance = ::LoadLibrary(pdllPath);
		if (hInstance)
		{
#ifndef _WIN32_WCE
			mPFTRACKInitDataPath = (PFTRACKInitDataPath)::GetProcAddress(hInstance,"CoInitDataPath");
			mPFTRACKInit= (PFTRACKInit)::GetProcAddress(hInstance,"CoInitTrack");
			mPFTRACKInit2 =(PFTRACKInit2)::GetProcAddress(hInstance,"CoInitTrack2");
			mPFTRACKUnInit=(PFTRACKUnInit)::GetProcAddress(hInstance,"CoUnInitTrack");
			mPFTRACKSetTrackMode=(PFTRACKSetTrackMode)::GetProcAddress(hInstance,"CoSetTrackMode");
			mPFTRACKGetTrackMode=(PFTRACKGetTrackMode)::GetProcAddress(hInstance,"CoGetTrackMode");
			mPFTRACKSetCameraCode=(PFTRACKSetCameraCode)::GetProcAddress(hInstance,"CoSetCameraCode");
			mPFTRACKGetCameraCode=(PFTRACKGetCameraCode)::GetProcAddress(hInstance,"CoGetCameraCode");
			mPFTRACKOffsetTrack=(PFTRACKOffsetTrack)::GetProcAddress(hInstance,"CoOffsetTrack");
			mPFTRACKSaveTrackSetting =(PFTRACKSaveTrackSetting)::GetProcAddress(hInstance,"CoSaveTrackSetting");
			mPFTRACKSetCameraID=(PFTRACKSetCameraID)::GetProcAddress(hInstance,"CoSetCameraID");
			mPFTRACKGetCameraID=(PFTRACKGetCameraID)::GetProcAddress(hInstance,"CoGetCameraID");
			mPFTRACKSetAngle=(PFTRACKSetAngle)::GetProcAddress(hInstance,"CoSetAngle");
			mPFTRACKSetScale=(PFTRACKSetScale)::GetProcAddress(hInstance,"CoSetScale");
			mPFTRACKinvoke =(PFTRACKinvoke)::GetProcAddress(hInstance,"CoTrackInvoke");
#else
			mPFTRACKInitDataPath = (PFTRACKInitDataPath)::GetProcAddress(hInstance,L"CoInitDataPath");
			mPFTRACKInit= (PFTRACKInit)::GetProcAddress(hInstance,L"CoInitTrack");
			mPFTRACKInit2 =(PFTRACKInit2)::GetProcAddress(hInstance,L"CoInitTrack2");
			mPFTRACKUnInit=(PFTRACKUnInit)::GetProcAddress(hInstance,L"CoUnInitTrack");
			mPFTRACKSetTrackMode=(PFTRACKSetTrackMode)::GetProcAddress(hInstance,L"CoSetTrackMode");
			mPFTRACKGetTrackMode=(PFTRACKGetTrackMode)::GetProcAddress(hInstance,L"CoGetTrackMode");
			mPFTRACKSetCameraCode=(PFTRACKSetCameraCode)::GetProcAddress(hInstance,L"CoSetCameraCode");
			mPFTRACKGetCameraCode=(PFTRACKGetCameraCode)::GetProcAddress(hInstance,L"CoGetCameraCode");
			mPFTRACKOffsetTrack=(PFTRACKOffsetTrack)::GetProcAddress(hInstance,L"CoOffsetTrack");
			mPFTRACKSaveTrackSetting =(PFTRACKSaveTrackSetting)::GetProcAddress(hInstance,L"CoSaveTrackSetting");
			mPFTRACKSetCameraID=(PFTRACKSetCameraID)::GetProcAddress(hInstance,L"CoSetCameraID");
			mPFTRACKGetCameraID=(PFTRACKGetCameraID)::GetProcAddress(hInstance,L"CoGetCameraID");
			mPFTRACKSetAngle=(PFTRACKSetAngle)::GetProcAddress(hInstance,L"CoSetAngle");
			mPFTRACKSetScale=(PFTRACKSetScale)::GetProcAddress(hInstance,L"CoSetScale");
			mPFTRACKinvoke =(PFTRACKinvoke)::GetProcAddress(hInstance,L"CoTrackInvoke");
#endif
		}
		return true;
	}
public:
	int   InitTrackDataPath(LPCTSTR lpstrindex,LPCTSTR lpstrData)
	{
		if (mPFTRACKInitDataPath)
		{
			return	mPFTRACKInitDataPath(lpstrindex,lpstrData);
		}
		return HBS_ERROR_NOINIT;
	}
	int   InitTrack(HWND hwnd){
		if (mPFTRACKInit)
		{
			return mPFTRACKInit(hwnd);
		}
		return HBS_ERROR_NOINIT;
	}
	int   InitTrack(FunTrackDataBack pCallBack,LPVOID lpdata){
		if (mPFTRACKInit2)
		{
			return mPFTRACKInit2(pCallBack,lpdata);
		}
		return HBS_ERROR_NOINIT;
	}
	int   SetTrackMode(int nMode){
		if (mPFTRACKSetTrackMode)
		{
			return mPFTRACKSetTrackMode(nMode);
		}	
		return HBS_ERROR_NOINIT;
	}
	int   GetTrackMode(){
		if (mPFTRACKGetTrackMode)
		{
			return mPFTRACKGetTrackMode();
		}
		return HBS_ERROR_NOINIT;

	}
	//////////////////////////////////////////////////////////////////////////
	int   SetCameraCode(int nTrackCode)
	{
		if (mPFTRACKSetCameraCode)
		{
			return mPFTRACKSetCameraCode(nTrackCode);
		}
		return HBS_ERROR_NOINIT;
	}
	int   GetCameraCode(int* pCode)
	{
		if (mPFTRACKGetCameraCode)
		{
			return mPFTRACKGetCameraCode(pCode);
		}
		return HBS_ERROR_NOINIT;
	}
	int   OffsetTrack(int nX,int nY){
		if (mPFTRACKOffsetTrack)
		{
			return mPFTRACKOffsetTrack(nX,nY);
		}
		return HBS_ERROR_NOINIT;
	}
	int  SaveTrackSetting()
	{
		if (mPFTRACKSaveTrackSetting)
		{
			return mPFTRACKSaveTrackSetting();
		}
		return HBS_ERROR_NOINIT;
	}
	//////////////////////////////////////////////////////////////////////////
	int   SetCameraID(IN CAMERA_IDENTIFY_ID *pData)
	{	
		if (mPFTRACKSetCameraID)
		{
			return mPFTRACKSetCameraID(pData);
		}
		return HBS_ERROR_NOINIT;
	}

	int   GetCameraID(OUT CAMERA_IDENTIFY_ID *pData)
	{
		if(mPFTRACKGetCameraID)
		{
			return mPFTRACKGetCameraID(pData);
		}
		return HBS_ERROR_NOINIT;
	}
	int   SetAngle(int nAngle){
		if(mPFTRACKSetAngle)
		{
			return mPFTRACKSetAngle(nAngle);
		}
		return HBS_ERROR_NOINIT;
	}
	int   SetScale(int nWndWidth,int nWndHeight){
		if (mPFTRACKSetScale)
		{
			return mPFTRACKSetScale(float(nWndWidth)/800,float(nWndHeight)/480);
		}
		return HBS_ERROR_NOINIT;
	}
	int   invoke(int nmessage,LPVOID pdata)
	{
		if(mPFTRACKinvoke)
		{
			return mPFTRACKinvoke(nmessage,pdata);
		}
		return HBS_ERROR_NOINIT;
	}
protected:
	HINSTANCE			 hInstance;
	PFTRACKInitDataPath	 mPFTRACKInitDataPath;
	PFTRACKInit			 mPFTRACKInit;
	PFTRACKInit2		 mPFTRACKInit2;
	PFTRACKUnInit		 mPFTRACKUnInit;
	PFTRACKSetTrackMode  mPFTRACKSetTrackMode;
	PFTRACKGetTrackMode  mPFTRACKGetTrackMode;
	PFTRACKSetCameraCode mPFTRACKSetCameraCode;
	PFTRACKGetCameraCode mPFTRACKGetCameraCode;
	PFTRACKOffsetTrack	 mPFTRACKOffsetTrack;
	PFTRACKSaveTrackSetting mPFTRACKSaveTrackSetting;
	PFTRACKSetCameraID	 mPFTRACKSetCameraID;
	PFTRACKGetCameraID	 mPFTRACKGetCameraID;
	PFTRACKSetAngle		 mPFTRACKSetAngle;
	PFTRACKSetScale      mPFTRACKSetScale;
	PFTRACKinvoke		 mPFTRACKinvoke;
};


#endif //end of __CO_BACKTRACK_API_H__