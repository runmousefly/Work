/************************************************************************
    Description: Back Track for coagent
    Author:lxl
    CopyRight: Coagent 
	Date:12/31/2013
	log:  															
************************************************************************/
#ifndef __CO_BACKTRACKDEF_H__
#define __CO_BACKTRACKDEF_H__

#include "TrackPlatfrom.h"
#include "Co_CarProtocoldef.h"
//////////////////////////////////////////////////////////////////////////
//Init datas divide to two way.
//User's HWND pointer for user using message.
typedef  void* PTrack_HWND;
//Call back function for the user no using message.
typedef  void(*FunTrackDataBack)(int ntype,LPVOID lpdata,LPVOID lpclass);

//////////////////////////////////////////////////////////////////////////
//The data struct for the Track translating
typedef struct _Point{
	int  x;
	int  y;
}Co_Point ,* PCo_Point;
//The transport data type.
enum{
	TRACK_TYPE_DATA  = 0,    //The Track data.
	TRACK_TYPE_CAR_NAME,	 //Car name of the track.
	TRACK_TYPE_ID_DATA,      //The id data for the camera.
	TRACK_TYPE_SETTINGMODE,	 //The setting mode.
	TRACK_TYPE_RETURN,		 //The reutrn value for some calls.
};
//Track display mode.
enum{
	TRACK_MODE_NORMAL = 0,  //Normal mode,Show the track and zero line
	TRACK_MODE_PARAM_INPUT,	//Just tell the user to input param.
	TRACK_MODE_SETTING,		//Setting mode show zero line,angle value,and car name.
	TRACK_MODE_NOTHING,		//Track display nothing.
};

//The data struct to descrip the track info
typedef struct _TRACK_DATA_INFO
{
	int				nPointCount;	// Points  Count of the offset data.
	int				nIsLastTrack;	// if this trackdata is the last trackdata for one update false/true.
	int			    ColorR;			// the color for the line.
	int             ColorG;
	int             ColorB;
	int      	    track_angle;	// current angle info to display.
}TRACK_DATA_INFO;
//The Track data.
//Notice that the start part of the data is the header info
//and the real data is start after the infoheader.
//for example:The first point is pointData[PTDATA_START_INDEX],
//the second point.x is  pt2.x=  pointData[PTDATA_START_INDEX].x+pPointOffsets[PTDATA_START_INDEX+1].x;
//The third point.x is pt3.x = pt2.x+pPointOffsets[PTDATA_START_INDEX+2].x;
#define  PTDATA_START_INDEX (sizeof(TRACK_DATA_INFO)/sizeof(Co_Point))
#define  MAX_TRACK_POINT 128
union TRACK_DATA 
{
	Co_Point		 pointData[MAX_TRACK_POINT];//The Point datas											
	TRACK_DATA_INFO  infoHeader;
};
#define  MAX_LINE_NUM 8

//The car name of the track.
struct TRACK_CAR_NAME{
	TCHAR   szCarName[32];
};
//The track identify id for the camera.
#define  TRACK_ID_NUM 12
typedef struct _CAMERA_IDENTIFY_ID{
	BYTE   bIDData[TRACK_ID_NUM];
}CAMERA_IDENTIFY_ID;

#ifndef _WIN32_WCE
#define  CO_STORGE_TrackPoint_PATH  L"C:\\TrackPoint.bin"
#define  CO_TrackPointIndex_PATH    L"C:\\TrackPointIndex.cfg"
#define  CO_BACKTRACK_DLL_PATH      L"Co_BackTrack.dll"
#else
#define  CO_STORGE_TrackPoint_PATH  L"\\NandFlash\\Application\\OriginalCarFun\\BackTrack\\TrackPoint.bin"
#define  CO_TrackPointIndex_PATH    L"\\NandFlash\\Application\\OriginalCarFun\\BackTrack\\TrackPointIndex.cfg"
#define  CO_BACKTRACK_DLL_PATH    L"\\NandFlash\\Application\\OriginalCarFun\\BackTrack\\Co_BackTrack.dll"
#endif

//--------- MCU --> WINCE -------------
#define MCU2APP_ADD_GID				0x5F 	//
#define MCU2APP_TRACK_DATA_RET  	0x10	//�켣��������ݶ���


//--------- WINCE --> MCU -------------
#define APP2MCU_ADD_GID				0x8F 	//
#define APP2MCU_TRACK_DATA_SAVE		0x90	//�켣���ݱ���
#define BACK_TRACK_DATA_LENTH	12
#define APP2MCU_TRACK_DATA_REQ		0x91	//�켣��������ݶ�������

#endif  // end of __CO_BACKTRACKDEF_H__