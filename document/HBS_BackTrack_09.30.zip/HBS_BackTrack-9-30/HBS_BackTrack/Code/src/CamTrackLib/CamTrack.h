#pragma once

#include <Windows.h>
#include "Co_BackTrackDef.h"
#include <vector>
using namespace std;

#define CAMERA_NUMBER   300 
//�Լ������Ƕ�����
extern "C"
{
#include "T_back.h"
};

typedef struct CameraInformation
{
	TCHAR camcode[32];
	int	  angle;
	int   offset;
	TCHAR deviceName[32];
	int   icamcode;
	int   nIndex;
	CameraInformation()
	{
		memset(&camcode, 0, sizeof(camcode));	
		angle   = 0;
		offset  = 0;
		icamcode= 0;
		nIndex  = 0;
		memset(&deviceName, 0, sizeof(deviceName));	
	};
}CAMERAINFO;

struct Track_Back{
	BYTE iCM_Type;		   //��ͷ���������ֵ
	BYTE iLen_Type;        //��Ƭ����
	BYTE bZE_Angle;		   //��е�Ƕ�У׼		   
	int  iTrack_x, iTrack_y;
	BYTE iAck;
};
#define ISVALIDHANDLE(h) ((h) != INVALID_HANDLE_VALUE&&(h) !=NULL)

class Track
{
public:
	Track(void);
	virtual ~Track(void);
public:
	void InitFilePaths(LPCTSTR lpstrIndex,LPCTSTR lpstrData);
	//��ͬ��֪ͨ��ʽ
	void InitTrack(HWND hwnd);
	void InitTrack(FunTrackDataBack pcallback,LPVOID lpclass);
	void UnInit();
public:
	bool SetCurrentAngle(int nCurAngle);
	bool SetCurrentAngle(UCHAR* pdata,int nNum);
	void UpdateTrack();
	bool SetTrackCode(int nCamCode,bool bUpdateTrack = true);
	int  GetTrackCode();
	void OffsetTrack(int nX,int nY);
	bool SetCameraID(CAMERA_IDENTIFY_ID *pData);
	void SaveTrackBackInfo();
	void GetTrackBackInfo();
	CAMERAINFO* GetCurrentCameraInfo();
	int  GetTrackSettingMode() const { return m_nTrackSettingMode; }
	void SetTrackSettingMode(int val,bool bNotify = false);
	void SendTrackData(int nIndex,Co_Point* pdata,int nNum);
	void SetScale(float fx,float fy);
public:
	vector<CAMERAINFO>  m_CamerainfoAll;	//���е���Ϣ
	Track_Back  m_Camsaveinfo;				//��ǰ��״̬
	BYTE	    camera_code[12];			//��ͷid��ƫ������			
	Co_Point*   m_pArray[8];				//������ָ��
	float		m_scalex;						
	float       m_scaley;
	TCHAR		m_szBufTrackPoint_path[MAX_PATH];
	TCHAR       m_szBufTrackPoint_index_path[MAX_PATH];
	//////////////////////////////////////////////////////////////////////////
protected:
	BOOL ReadTrackData(int AngIndex,char *pInPutBuffer);
	BOOL ReadAngle(int *maxangle,int *minangle);
	BOOL ReadStopLineData(int nlineIndex,char *pInPutBuffer);
	int  GetCurrentAngleIndex(int tempangle,int zeroangle,int maxoffset,int maxangle);
	void CorrectAngleIndex();
	void BuildCommonLineData(int nIndex,char *pBuf);
	void BuildTrackData(char* pBuf);
	int  FindCamerinfoByCMType(int nIndex);
	bool OpenTrackData() ;
	bool ReadTrackPointIndex();
	void CalcCamIDCode();
	int  OffsetX4Correct();
	int  OffsetY4Correct();
	bool IsTrackOK();
	void ResetTrackVar();
	HANDLE		hBinFile;
	char		*pTrackData,*pStopLineData;
	int			OldAngleIndex;				//
	BOOL		IsTrackInLeft ;
	BOOL		IsTrackInRight;
	int			m_curAngle;					//��ǰ�Ƕ�
	BOOL		m_bModeShowZero;
	int			m_nTrackSettingMode;
	int		    MaxAngle,MinAngle;			//�����С�Ƕ�
	int		    AngIndex;					// -45---45	
protected:
	HWND	    m_hwnd;
	FunTrackDataBack   m_funSendData;
	LPVOID      m_renderclass;				//
};
