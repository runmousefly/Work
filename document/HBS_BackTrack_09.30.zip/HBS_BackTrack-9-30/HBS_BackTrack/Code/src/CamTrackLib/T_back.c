
//��STM32�õ����ļ�
#ifdef __COMMIT_BY_LXL__
#include "global_reg.h"
#include "stm32f10x_lib.h"
#include "PREDEF.h"
#include "back.h"
#include "audio.h"
#include "TIM.h"
#include "T_back.h"
#include "stdlib.h"
#include "comm.h"
#include "MST776.h"
#include "menu.h"
#include "DAC.h"
#include "CANapp.h"
#else
#include "T_back.h"
#endif

#define BACK_dec_code_val	6	//ԭ121 ljh_chg
#define CAM_PASSB 0x0000
#define CAM_PASSC 0x0120
#define CAM_PASSD 0x1208

u8 BACK_rear_state;
u16 BACK_rear_rece_cont;
u8 BACK_rear_keym;
u32 BACK_rear_kval;
u8 t_dat_num;
u8 BACK_cam_chk_val;
u16 BACK_dec_code_set;
u8 BACK_dec_code;
u16 BACK_tdat_hval[5];
u16 BACK_tdat_lval[5];
u8 BACK_disp_angle;
u8 BACK_wheel_angle;
u32 BACK_tdat_oldval;
u8 BACK_angle_point_tmp;
u8 BACK_angle_point_tmp_h;
u8 BACK_angle_point;
u8 BACK_angle_point_h;
u8 BACK_fxp_max_angle;
u8 BACK_wheel_max_angle;
u8 BACK_angle_send_en;
u8 BACK_point_mirror;
u8 BACK_new_dec_fxp_max;
u8 BACK_new_dec_wheel_max;
u8 cam_xoffset;
u8 cam_yoffset;
u8 cam_xoffset_tmp;
u8 cam_yoffset_tmp;
u8 CAN_data_flag;
u8 CAN_angle_data[8];
u8 cam_code;
u8 back_track_mode_en;
u32 offset_tmp[2];
u8 cam_sum;
u8 offset_input_en;
u8 cam_chk_sum;
u8 pass_numid;
u16 passward;
u16 canid_val;
u16 new_dec_canid;
u8 Track_en;

#define cam_NUM 102
vuc16 cam_dec_tab[]=
{
	0x2390,//CA3900,�µ�A6L,CMOS 0
	0x2300,//CA3600,��������,CMOS 1
	0x0000,//CA2321,�������� Micron  2
	0x2039,//CA109-A,����.800x480,Micron 3 
	0x2054,//������ŷ.800x480,Micon	  4
	0x2307,//CA105-A,˹�´���� Micron  5
	0x2080,//CA908-T,�µ�A4L13��.800x480,micron	6	// 0x2319,//CA3519,�������ۼ���,CCD
	0x1354,//CA3654,�ղ��п�-1.800x480,ԭ����ͷ  7
	0x2321,//CA3621,��������,CMOS	   8
	0x2055,//HBS155-A,���Ӣ������.800x480,CMOS
	0x2324,//K330,��������,CMOS	   10
	0x2057,//CA3639G,2011���Ÿ�,Micron 11
	0x2336,//CA3636,�ɵ�ŷ��ʤ,CMOS   12
	0x2328,//CA3628,ѩ�����¾���,CMOS 13
	0x2331,//CA3631,�㱾�淶,CMOS	   14
	0x2028,//HBS131-A,������־10��,Micron 15
	0x2038,//-1,CA155-A,���Ӣ��Micron,  16
	0x2062,//CA284-T,�ղ������,Micron (20110803����)	17
	0x0000,//2049-1,//SUB201101LE,˹��³����,Micron	   18
	0x2045,//HBS108-A,�����ִ�IX35	   19
	0x2072,//CA312-T,����������B7L,Micron	   20
	0x2347,//CA3647,˹��³ɭ����,CMOS 21
	0x2350,//CA3650,ѩ��������,CMOS   22
	0x2352,//CA3652,˹�´�����,CMOS   23
	0x2354,//CA3654,�ղ��п�,CMOS	   24
	0x2070,//CA305-T,��־508,micron   25
	0x2358,//CA3658,����307,CMOS	   26
	0x2359,//CA3659,�ִ��ö�,CMOS	   27
	0x2360,//CA6012,��������,CCD	   28
	0x2361,//CA2361,��������,CCD	   29
	0x2083,//CP2083,C909-T,�µ�Q3,Micron	   30	//0x2362,//CA3118,һ������,CCD	   30
	0x2363,//CA6023,����A3,û��	   31
	0x2127,//CA127-A,�ղ�����.800x480,Micron 32
	0x2036,//CA140-A,ѩ����C5 Micron  33
	0x2366,//CA6005,������ӥ,CCD	   34
	0x2367,//CA6019,С����,û��	   35
	0x2035,//CA161-A,��ŵ���װ�.800x480,Micro 36
	0x2049,//CA146-A,����.800x480,Micron 37
	0x2371,//CA3901,����5ϵ,CMOS	   38
	0x2374,//CA3666,����¾���,CMOS   39
	0x2376,//CA3605,����;��,û��	   40
	0x2047,//HBS160-A,����350.800x480,Micron 41
	0x2381,//K381  ,���ǵ�F3          42
	0x2046,//HBS182-A,���⾢��.800x480,Micron 43
	0x2048,//HBS191-A,��������.800x480,Micron 44
	0x2355,//K337�ɶ�                 45 
	0x2387,//CA3670,�µ���            46 
	0x2040,//HBS146-A,��ʨ.800x480,Micron	 47
	0x2066,//CA135-T,��������,Micron		 48
	0x2333,//CA2333-1,CA3633,������-1,Micron   49
	0x2339,//CA2339-1,CA3639,�㱾�Ÿ�-1,Micron 50
	0x2386,//CA2386,CA3610,ѩ������³��,Micron 51
	0x2393,//CA2393,CA3608,��˾�Խ09,MICRON	52
	0x2344,//CA2344,CA3675,���Ǹ����,MICRON	53
	0x2332,//CA2332,CA3681,������,MICRON		54
	0x2345,//CA2345,K6015,��������ʿ,MICRON	55
	0x2322,//CA3622,��������Ԧ-1,Micron		56
	0x2341,//CA3641,09������,MICRON			57
	0x0000,//CA3625,����ʹ�-1,Micron			58
	0x2316,//CA3616,������־,CCD               59
	0x2357,//CA3657,����CR-V-1,Micron			60
	0x2318,//CA3680,���ǵ�F6					61
	0x2392,//K6048,��ľ����					62
	0x2372,//CA0000,�ִ�;ʤ					63
	0x2317,//CA3903,�µ�A4L					64
	0x2391,//CA3691,���ھ���					65
	0x2379,//CA6342,����S30					66
	0x2384,//CA6043,�����ۺ�,Micron			67
	0x2342,//CA3687,�ղ��ô�,Micron			68
	0x2370,//CA6041,���ǿ���,Micron			69
	0x2378,//CA6041,��������,Micron			70
	0x2327,//CA6038,�л�����,Micron			71
	0x2202,//CA3686,�׿���˹,Micron			72
	0x2365,//CA-A102,�µ���09��.800x480,Micron	73
	0x2389,//CA-A101G,����ʹ�13��Micron		74
	0x2051,//HBS193-K,�ִ�����.800x480,Micron	75
	0x0000,//									76
	0x2395,//CA3674,����˼���,Micron			77
	0x2396,//CA-????,��˰�����.800X400,Micron 78 
	0x2383,//CA6627,��������.800X400,Micron	79
	0x2346,//CA3646,�����·��.800X400,Micron	80
	0x2004,//CA3656,����ʨ��.800X400,Micron	81
	// 0x2382,//CA3667,����RAV4-1,Micron			82
	0x2074,//SUB201202XV,˹��³XV.800x480,Micron 82
	0x0000,//CA3619,���ﻨ��-1,Micron����	    83
	0x2010,//CA3636,����˹����Micron			84
	0x2007,//K119-A,���ǵ�G3.800x480,Micron	85
	0x2385,//K6048G,��ľ�������.800x480,Micron 86
	0x0000,//,CA3602,�ղ�������.800x480,Micron  87
	0x2320,//CA3620,������08��.800X400,Micron   88
	0x2006,//CA3668,������09��.800x480,Micron	 89
	0x2304,//CA3677,����������.800X400,Micron	 90
	0x0000,//CA3901,����5ϵ.800x480,Micron		 91
	0x0000,//CA6605,������ӥ-1.800x480,Micron	 92
	0x2020,//CA132-A,�������ö���.800x480,Micron 93
	0x0000,//-1,CA6612Z,��������-1.800x480,Micron  94
	0x2025,//CA142-A,����;��.800x480,Micron		95
	0x0000,//D,CA-A101G,����ʹ�13��-1.800x480,Micron 96
	0x2019,//K113Z,����ͬ������,Micron	   97
	0x2021,//CA6049G,������������.800x480,Micron  98
	0x2015,//CA126-A,����Ե�10��.800x480,Micron  99
	0x2314,//-1,CA3636,����˹����.800x480,Micron  100
	0x2053,//ŷ��������.800x480,Micon  101
};

#define CANID_CROWN			0x025
#define TDATA_LEFT_CROWN	430
#define TDATA_RIGHT_CROWN	405
#define CROWN_DIV			0.095//3/31  //

#define CANID_PRADO			0x025
#define TDATA_LEFT_PRADO	360
#define TDATA_RIGHT_PRADO	368
#define PRADO_DIV			0.11//1/9  //

#define CANID_CAROLLA			0x025
#define TDATA_LEFT_CAROLLA		440
#define TDATA_RIGHT_CAROLLA	    424
#define CAROLLA_DIV			   0.092//3/32  //
#define YIZI_DIV			   0.105//3/32  //

#define CANID_KAIXUAN			0x305
#define TDATA_LEFT_KAIXUAN		5063
#define TDATA_RIGHT_KAIXUAN	    5007
#define KAIXUAN_DIV			   0.008//1/142 //

#define CANID_BZ508			    0x10B
#define TDATA_LEFT_BZ508		5206
#define TDATA_RIGHT_BZ508	    5172
#define BZ508_DIV			   0.0078//1/142 //

#define CANID_MAGOTAN			0x0C2
#define TDATA_LEFT_MAGOTAN		385
#define TDATA_RIGHT_MAGOTAN	    383
#define MAGOTAN_DIV			   0.098//1/10  //

#define CANID_MAGOTAN_B7			0x3C3
#define TDATA_LEFT_MAGOTAN_B7		388
#define TDATA_RIGHT_MAGOTAN_B7	    386
#define MAGOTAN_B7_DIV			   0.1//1/10  //

#define CANID_REIZ			0x025
#define TDATA_LEFT_REIZ	    414
#define TDATA_RIGHT_REIZ	415
#define REIZ_DIV		    0.095//1/10   //

#define CANID_ACCORD			0x1B0
#define TDATA_LEFT_ACCORD		473
#define TDATA_RIGHT_ACCORD	    468
#define ACCORD_DIV		        0.082//1/12  //

#define CANID_REGAL				0x180
#define TDATA_LEFT_REGAL		8070
#define TDATA_RIGHT_REGAL		8072
#define REGAL_DIV		        0.00496//1/200  //

#define CANID_SENLINREN			0x002
#define TDATA_LEFT_SENLINREN	9134
#define TDATA_RIGHT_SENLINREN	9185
#define SENLINREN_DIV		    0.00437//1/230  //0.00437

#define CANID_AOHU			0x02														 
#define TDATA_LEFT_AOHU	    5786
#define TDATA_RIGHT_AOHU	5617
#define AOHU_DIV		    0.0068//1/142  //

#define CANID_LISHI			0x02
#define TDATA_LEFT_LISHI    5200
#define TDATA_RIGHT_LISHI	5186
#define LISHI_DIV		    0.0077//1/129   //


#define CANID_TURUI			0x3C3
#define TDATA_LEFT_TURUI	376
#define TDATA_RIGHT_TURUI	382
#define TURUI_DIV		    0.105//1/10  //

#define CANID_TUGUAN		0x3C3
#define TDATA_LEFT_TUGUAN	348
#define TDATA_RIGHT_TUGUAN	342
#define TUGUAN_DIV		    0.112//1/9  //

#define CANID_LEXUS			0x025
#define TDATA_LEFT_LEXUS	340
#define TDATA_RIGHT_LEXUS	440
#define LEXUS_DIV		    0.1//3/34  //

#define CANID_JUNYUE			0x1E5
#define TDATA_LEFT_JUNYUE		8049
#define TDATA_RIGHT_JUNYUE		8143
#define JUNYUE_DIV		        0.0049//1/200   //

#define CANID_ANGKELEI				0x1E5
#define TDATA_LEFT_ANGKELEI			8418
#define TDATA_RIGHT_ANGKELEI		8393
#define ANGKELEI_DIV		        0.00475//1/210  //

#define CANID_XIC5				0x305
#define TDATA_LEFT_XIC5			5306
#define TDATA_RIGHT_XIC5		5343
#define XIC5_DIV		        0.0075//1/133  //

#define CANID_JINXUAN			0x33B
#define TDATA_LEFT_JINXUAN		1197
#define TDATA_RIGHT_JINXUAN		1218
#define JINXUAN_DIV		        0.033//1/30  //

#define CANID_JEEP			    0x015
#define TDATA_LEFT_JEEP		1052
#define TDATA_RIGHT_JEEP		1083
#define JEEP_DIV		        0.037//1/30  //

#define CANID_A4L			    0x086
#define TDATA_LEFT_A4L		    5248
#define TDATA_RIGHT_A4L		    5248
#define A4L_DIV		             0.0076//1/30  //

#ifdef __COMMIT_BY_LXL__
void TCAN_set(u8 onf);
#endif

void TDEC_CHK_set(u8 onf)
{
#ifndef __COMMIT_BY_LXL__
	if(onf==ENABLE)
	{
		GPIO_config(tchk_data,GPIO_Mode_IN_FLOATING);
		GPIO_EXTILineConfig(GPIO_PortSourceGPIOD, GPIO_PinSource13);
		EIC_ExternalITTriggerConfig(EXTI_Line13, EXTI_Trigger_Falling);
		NVIC_IRQChannelConfig(EXTI15_10_IRQChannel, ENABLE);
		EXTI_ClearITPendingBit(EXTI_Line13);
		EIC_IRQChannelConfig(EXTI_Line13, DISABLE );
		NVIC_IRQChannelConfig(TIM2_IRQChannel, ENABLE); 
		TIM_Cmd(TIM2, DISABLE); 
		TIM_ClearITPendingBit(TIM2, TIM_IT_CC4);
		TIM_ITConfig(TIM2, TIM_IT_CC4, ENABLE);
	}
	else
	{
		EIC_IRQChannelConfig(EXTI_Line13, DISABLE );
		TIM_ITConfig(TIM2, TIM_IT_CC4, DISABLE);
	}
#endif
}

void TIM2_cl_tdec(void)
{
#ifndef __COMMIT_BY_LXL__
	if(BACK_rear_state==REAR_SEND)
	{
		BACK_rear_rece_cont=0;
		if(BACK_rear_keym<11)
		{
			if(BACK_rear_keym==0)
			{
				GPIO_WriteBit(tchk_data, Bit_SET);
				TIM_SetCounter(TIM2, 0);
				TIM_SetCompare4(TIM2,800);  //800BACK_rear_kval
			}
			else if(BACK_rear_keym==1)
			{
				GPIO_WriteBit(tchk_data, Bit_RESET);
				TIM_SetCounter(TIM2, 0);
				TIM_SetCompare4(TIM2,100);  //100uS
			} //=1
			else if(BACK_rear_keym%2)
			{
				GPIO_WriteBit(tchk_data, Bit_RESET);
				TIM_SetCounter(TIM2, 0);
				TIM_SetCompare4(TIM2,100);  //100uS	
			}
			else
			{
				GPIO_WriteBit(tchk_data, Bit_SET);
				TIM_SetCounter(TIM2, 0);
				if(BACK_rear_kval&0x000008)
					TIM_SetCompare4(TIM2,300);  //300uS
				else
					TIM_SetCompare4(TIM2,100);  //100uS	
				BACK_rear_kval<<=1;
			}
		} //keym<11
		BACK_rear_keym++;
		if(BACK_rear_keym==11)
		{
			GPIO_WriteBit(tchk_data, Bit_SET);
			GPIO_config(tchk_data,GPIO_Mode_IN_FLOATING);
			EXTI_ClearITPendingBit(EXTI_Line13);
			EIC_IRQChannelConfig(EXTI_Line13, ENABLE );
			TIM_SetCounter(TIM2, 0);
			TIM_SetCompare4(TIM2,4500);  //4500uS
			BACK_rear_state=REAR_SEND_END;
		}
		BACK_rear_rece_cont=0;
	}//send

	else if(BACK_rear_state==CHK_OK_SEND)
	{
		if(BACK_rear_keym==0)
		{
			GPIO_WriteBit(tchk_data, Bit_SET);
			TIM_SetCounter(TIM2, 0);
			TIM_SetCompare4(TIM2,1800);  //1800us
		}
		else if(BACK_rear_keym==1)
		{
			GPIO_WriteBit(tchk_data, Bit_RESET);
			TIM_SetCounter(TIM2, 0);
			TIM_SetCompare4(TIM2,100);  //100us
		}
		else if(BACK_rear_keym==2)
		{
			GPIO_WriteBit(tchk_data, Bit_SET);
			GPIO_config(tchk_data,GPIO_Mode_IN_FLOATING);
			EIC_ExternalITTriggerConfig(EXTI_Line13, EXTI_Trigger_Falling);
			EXTI_ClearITPendingBit(EXTI_Line13);
			EIC_IRQChannelConfig(EXTI_Line13, ENABLE );
			TIM_SetCounter(TIM2, 0);
			TIM_SetCompare4(TIM2,4500);  //4500uS
			BACK_rear_state=REAR_WAIT_ACK_START;

		}
		BACK_rear_keym++;
	} //rear_state==CHK_OK_SEND


	else if((BACK_rear_state==REAR_SEND_END)||(BACK_rear_state==REAR_RECE_START)
		||(BACK_rear_state==REAR_WAIT_ACK_START)||(BACK_rear_state==REAR_ACK_START))
	{
		TIM_Cmd(TIM2, DISABLE); 
		BACK_rear_state=CHK_ERR_STATE;
	}
	TIM_ClearITPendingBit(TIM2, TIM_IT_CC4);
#endif
}

vuc8 cam_chk_TAB[16]={20,4,9,6,27,23,15,11,2,5,3,7,13,17,31,8};
void tdec_chk_IT_task(void)
{
#ifndef __COMMIT_BY_LXL__
	u16 chk_val;
	u16 rtime;
	u16 offset;
	if(BACK_rear_state==REAR_SEND_END)
	{
		BACK_rear_state=REAR_RECE_START;
		TIM_SetCounter(TIM2, 0);
		EIC_ExternalITTriggerConfig(EXTI_Line13, EXTI_Trigger_Rising);
	}
	else if(BACK_rear_state==REAR_RECE_START)
	{
		rtime=TIM_GetCounter(TIM2);
		TIM_Cmd(TIM2, DISABLE);
		chk_val=(cam_chk_TAB[BACK_cam_chk_val]*100);
		offset=cam_chk_TAB[BACK_cam_chk_val]*5;
		if(offset<50)
			offset=50;
		if((rtime>(chk_val-offset))&&(rtime<(chk_val+offset)))
			BACK_rear_state=REAR_RECE_OK;
		else
			BACK_rear_state=CHK_ERR_STATE;
		EIC_IRQChannelConfig(EXTI_Line13, DISABLE );
	}

	else if(BACK_rear_state==REAR_WAIT_ACK_START)
	{
		BACK_rear_state=REAR_ACK_START;
		TIM_SetCounter(TIM2, 0);
		EIC_ExternalITTriggerConfig(EXTI_Line13, EXTI_Trigger_Rising);
	} 

	else if(BACK_rear_state==REAR_ACK_START)
	{
		rtime=TIM_GetCounter(TIM2);
		TIM_Cmd(TIM2, DISABLE);
		if(rtime>3000)
			BACK_rear_state=CHK_ERR_STATE;
		else
			BACK_rear_state=REAR_RECE_OK;
		EIC_IRQChannelConfig(EXTI_Line13, DISABLE );
	} 


	EXTI_ClearITPendingBit(EXTI_Line13);
#endif
}


void delay_1us(u16 ust)
{
	u16 dt;
	while(ust--)
	{
		for(dt=0;dt<8;dt++)
		{
		}
	}
}


u8 CAM_CHK(void)
{
#ifndef __COMMIT_BY_LXL__
	u16 t_cont;
	t_cont=0;
	if((BACK_dec_code==7)||(BACK_dec_code==76)||(BACK_dec_code==101))
		return(ENABLE);

	SEN_CAN_pin_set(DISABLE);
	TDEC_CHK_set(ENABLE);
	while(GPIO_ReadInputDataBit(tchk_data)==Bit_RESET) 
	{
		t_cont++;
		if(t_cont>100)
			return(DISABLE);
		delay(1);
	}
	GPIO_config(tchk_data,GPIO_Mode_Out_PP);
	BACK_cam_chk_val=((u8)rand()%0x0f); 
	BACK_rear_kval=BACK_cam_chk_val;
	BACK_rear_keym=0;
	GPIO_WriteBit(tchk_data,Bit_RESET);
	TIM_SetCounter(TIM2, 0);
	TIM_SetCompare4(TIM2,1500);  //1500uS
	TIM_Cmd(TIM2, ENABLE); 
	BACK_rear_rece_cont=0;
	Track_en=DISABLE;
	BACK_rear_state=REAR_SEND;
	while(1)
	{
		BACK_rear_rece_cont++;
		delay_1us(20);//20uS
		if(BACK_rear_rece_cont>1000)
			return(DISABLE);
		if(BACK_rear_state==CHK_ERR_STATE)
			return(DISABLE);
		else if(BACK_rear_state==REAR_RECE_OK)
		{
			if(Cam_chk_success()==ENABLE)
			{
				Track_en=ENABLE;
				return(ENABLE);
			}
			else
				return(DISABLE);
		}
	}
#else
	return (DISABLE);
#endif
}


u8 Cam_chk_success(void)
{
#ifndef __COMMIT_BY_LXL__
	u8 m;
	if((BACK_dec_code==7)||(BACK_dec_code==76)||(BACK_dec_code==101))
	{
		Track_en=ENABLE;
		return(ENABLE);
	}

	for(m=0;m<3;m++)
	{
		delay(1000);
		SEN_CAN_pin_set(DISABLE);
		TDEC_CHK_set(ENABLE);
		GPIO_config(tchk_data,GPIO_Mode_Out_PP);
		GPIO_WriteBit(tchk_data,Bit_RESET);
		TIM_SetCounter(TIM2, 0);
		TIM_SetCompare4(TIM2,1500);  //1500uS
		TIM_Cmd(TIM2, ENABLE); 
		BACK_rear_rece_cont=0;
		BACK_rear_keym=0;
		Track_en=DISABLE;
		BACK_rear_state=CHK_OK_SEND;
		while(1)
		{
			BACK_rear_rece_cont++;
			delay_1us(5);//5uS
			if(BACK_rear_rece_cont>2500)
				break;
			if(BACK_rear_state==CHK_ERR_STATE)
				break;
			else if(BACK_rear_state==REAR_RECE_OK)
			{
				Track_en=ENABLE;
				return(ENABLE);
			}
		}
	}
#endif
	return(DISABLE);
}



void dec_code_TAB(void)
{
	u16 tmp;
	u8 i;
	if(BACK_dec_code_set==0x2078)
		BACK_dec_code=111;
	else if(BACK_dec_code_set==0x2079)
		BACK_dec_code=119;				  //jeep
	else if(BACK_dec_code_set==0x2082)
		BACK_dec_code=120;				 //˹��³ɭ����2013
	else if(BACK_dec_code_set==0x2080)
		BACK_dec_code=BACK_dec_code_val;	//121;				 //121=CP2080,CA908-T,�µ�A4L13��.800x480,micron
	else
	{
		for(i=0;i<cam_NUM;i++)
		{
			tmp=(cam_dec_tab[i]&0xffff);
			if(tmp==BACK_dec_code_set)
			{
				BACK_dec_code=i;
				if((BACK_dec_code==21)&&(cam_code==1))
					BACK_dec_code=76;
				return;
			}
		}
		BACK_dec_code=0xff;
	}
}


u16 average_val_data(u16 *datmp)
{
	u16 max;
	u16 min;
	u8 m;
	u16 data_tmp;
	u16 angle_tmp;
	max=0;
	min=0xffff;
	angle_tmp=0;
	for(m=0;m<5;m++)
	{
		data_tmp=(datmp[m]/8);
		angle_tmp+=data_tmp;
		if(data_tmp>max)
			max=data_tmp; 
		if(data_tmp<min)
			min=data_tmp; 	 
	}
	angle_tmp=((angle_tmp-max-min)/3);
	return(angle_tmp);
}


void cap_data_proce(void)
{
	u16 angle_tmp[2];
	u8 m;
	u8 angle_data;
	u32 tmp;
	angle_tmp[0]=average_val_data(BACK_tdat_hval);
	angle_tmp[1]=average_val_data(BACK_tdat_lval);
	tmp=(angle_tmp[1]*255);
	if(BACK_tdat_oldval>tmp)
	{
		if((BACK_tdat_oldval-tmp)<angle_tmp[0])
		{
			tmp=BACK_tdat_oldval;
		}
		else
			BACK_tdat_oldval=tmp;
	} 
	else
	{
		if((tmp-BACK_tdat_oldval)<angle_tmp[0])
		{
			tmp=BACK_tdat_oldval;
		}
		else
			BACK_tdat_oldval=tmp;
	}
	angle_data=(u8)(tmp/angle_tmp[0]);


	BACK_angle_point_tmp=angle_data;
	if(angle_data>BACK_angle_point)
	{
		m=(angle_data-BACK_angle_point);
		if((m>BACK_fxp_max_angle)&&((256-m)<0x80))
			angle_data=(256-m)|0x80;
		else
			angle_data=m;
	}
	else
	{
		m=(BACK_angle_point-angle_data);
		if((m>BACK_fxp_max_angle)&&((256-m)<0x80))
			angle_data=(256-m);
		else
			angle_data=m|0x80;
	}

	BACK_wheel_angle=(angle_data&0x80);
	angle_data&=0x7f;
	m=((angle_data*BACK_wheel_max_angle)/BACK_fxp_max_angle);
	if(m>BACK_wheel_max_angle)
		m=BACK_wheel_max_angle;
	BACK_wheel_angle+=m;
	if(BACK_wheel_angle==0x80)
		BACK_wheel_angle=0;
	if(BACK_wheel_angle^BACK_disp_angle)
		BACK_angle_send_en=ENABLE;
}


void wheel_angle_send(u8 angle)
{
#ifndef __COMMIT_BY_LXL__
	u8 mst_Buff[2];

	if((BACK_disp_angle==angle)||(Track_en==DISABLE))
	{
		BACK_angle_send_en=DISABLE;
		return;
	}

	BACK_disp_angle=angle;
	if(BACK_point_mirror==0)
		mst_Buff[0]=angle;
	else
	{
		mst_Buff[0]=(angle&0x7f);
		if((angle&0x80)==0)
			mst_Buff[0]|=0x80;
	}
	MST716_send(0x21,mst_Buff,1,0);
	BACK_angle_send_en=DISABLE;
#endif
}

//��е�켣�����ô���
void TIM4_IT_CAP_TASK(void)
{
#ifndef __COMMIT_BY_LXL__
	TIM_ClearITPendingBit(TIM4, TIM_IT_CC2|TIM_IT_CC1); 

	if(t_dat_num>49)
		t_dat_num=0;
	if((t_dat_num%10)==0)
	{
		/* Get the Input Capture value */
		BACK_tdat_lval[t_dat_num/10] = TIM_GetCapture1(TIM4);
		BACK_tdat_hval[t_dat_num/10] = TIM_GetCapture2(TIM4);
	}
	t_dat_num++;
	if(t_dat_num>49)
	{
		t_dat_num=0;
		if(get_tcan_en()==0)
			cap_data_proce();
	}
#endif
}


void disp_offset_menu(void)
{
#ifndef __COMMIT_BY_LXL__
	menu_set(0);
	cam_xoffset_tmp=cam_xoffset;
	cam_yoffset_tmp=cam_yoffset;
	delay(8000);
	wheel_angle_send(0);
	delay(1000);
	back_track_offset_send(cam_xoffset_tmp,cam_yoffset_tmp);
	delay(1000);
	osd_offset(ENABLE);
#endif
}

void disp_point_menu(void)
{
#ifndef __COMMIT_BY_LXL__
	menu_set(1);
	if(get_tcan_en()==1)
		TCAN_set(ENABLE);
#endif
}

void back_track_offset_send(u8 xoff,u8 yoff)
{
#ifndef __COMMIT_BY_LXL__
	u8 mst_Buff[6];
	mst_Buff[0]=xoff;
	mst_Buff[1]=yoff;
	mst_Buff[2]=BACK_dec_code;
	if(cam_code==1)
	{
		switch(BACK_dec_code)
		{
		case 6://���ﻨ��-1
			mst_Buff[2]=83;
			break;

		case 8://��������	Micron
			mst_Buff[2]=2;
			break;

		case 11://����ʹ�	Micron
			mst_Buff[2]=58;
			break;


		case 21://˹��³ɭ���˹̶�������
			mst_Buff[2]=76;
			break;


		case 28://��������
			mst_Buff[2]=94;
			break;

		case 34://������ӥ-1
			mst_Buff[2]=92;
			break;

		case 37://˹��³����-1
			mst_Buff[2]=18;
			break;

		case 38://����5ϵ
			mst_Buff[2]=91;
			break;

		case 74://����ʹ�13��
			mst_Buff[2]=96;
			break;
		}
	}
	mst_Buff[3]=Get_track_mode();
	MST716_send(0x22,mst_Buff,4,0);
#endif
}



void offset_con(u8 tkval)
{
#ifndef __COMMIT_BY_LXL__
	u8 osm[16];
	u8 set_en=DISABLE;
	switch(tkval)
	{
	case 0:  //up
		if(cam_yoffset_tmp==0)
		{
			cam_yoffset_tmp=0x81;
			set_en=ENABLE;
		}
		else if((cam_yoffset_tmp<0x80)&&(cam_yoffset_tmp>0))
		{
			cam_yoffset_tmp--;
			set_en=ENABLE;	  
		}
		else if(cam_yoffset_tmp<0xff) 
		{
			cam_yoffset_tmp++;
			set_en=ENABLE;
		}
		set_key_serid(0x30);
		break;

	case 1:  //left
		if(cam_xoffset_tmp==0)
		{
			cam_xoffset_tmp=0x81;
			set_en=ENABLE;
		}
		else if((cam_xoffset_tmp<0x80)&&(cam_xoffset_tmp>0))
		{
			cam_xoffset_tmp--;
			set_en=ENABLE;	  
		}
		else if(cam_xoffset_tmp<0xff) 
		{
			cam_xoffset_tmp++;
			set_en=ENABLE;
		}
		set_key_serid(0x31);
		break;

	case 2:  //down
		if(cam_yoffset_tmp==0x80)
		{
			cam_yoffset_tmp=1;
			set_en=ENABLE;
		}
		else if((cam_yoffset_tmp<=0xff)&&(cam_yoffset_tmp>0x80))
		{
			cam_yoffset_tmp--;
			set_en=ENABLE;	  
		}
		else if(cam_yoffset_tmp<0x80) 
		{
			cam_yoffset_tmp++;
			set_en=ENABLE;
		}
		set_key_serid(0x32);
		break;

	case 3:  //right
		if(cam_xoffset_tmp==0x80)
		{
			cam_xoffset_tmp=1;
			set_en=ENABLE;
		}
		else if((cam_xoffset_tmp<=0xff)&&(cam_xoffset_tmp>0x80))
		{
			cam_xoffset_tmp--;
			set_en=ENABLE;	  
		}
		else if(cam_xoffset_tmp<0x80) 
		{
			cam_xoffset_tmp++;
			set_en=ENABLE;
		}
		set_key_serid(0x33);
		break;


	case 4:
		osm[0]='#';
		osm[1]=(((BACK_dec_code_set>>12)&0x0f)+0x30);
		osm[2]=(((BACK_dec_code_set>>8)&0x0f)+0x30);
		osm[3]=(((BACK_dec_code_set>>4)&0x0f)+0x30);
		osm[4]=((BACK_dec_code_set&0x0f)+0x30);
		osm[5]=((cam_code&0x07)+0x30);
		osm[6]=((cam_xoffset_tmp/100)+0x30);
		osm[7]=(((cam_xoffset_tmp%100)/10)+0x30);
		osm[8]=((cam_xoffset_tmp%10)+0x30);
		osm[9]=((cam_yoffset_tmp/100)+0x30);
		osm[10]=(((cam_yoffset_tmp%100)/10)+0x30);
		osm[11]=((cam_yoffset_tmp%10)+0x30);
		osm[12]=(cam_sum+0x30);
		osm[13]='#';

		cam_code_print(osm);

		Sys_mode_power(POW_CAM_OFF);
		delay(20000);
		Sys_mode_power(POW_CAM_ON);
		delay(5000);

		back_mode_chk();
		TIM_ITConfig(TIM2, TIM_IT_CC2, DISABLE);
		Cam_ID_Chk();
		if(get_tcan_en()==1)
			TCAN_set(ENABLE);
		else
			TIM4_CAP_IN_SET();
		if((get_T_back_cam_en()==DISABLE)||(get_tback_device()==DISABLE))
		{
			disp_cam_input_state(DISABLE);
		}
		else
		{
			disp_cam_input_state(ENABLE);
		}
		break;


	case TKEY_EXIT:
		//      cam_xoffset=cam_xoffset_tmp;
		//      cam_yoffset=cam_yoffset_tmp;
		//      camset_eprom(DISABLE);
		menu_display(NO_MENU,20);
		disp_cam_in();
		break;

	}
	if(set_en==ENABLE)
	{ 
		dec_code_TAB();
		back_track_offset_send(cam_xoffset_tmp,cam_yoffset_tmp);
		delay(1000);
		osd_offset(DISABLE);
	}
#endif
}


void point_con(u8 pkval)
{
#ifndef __COMMIT_BY_LXL__
	beep_set();
	switch(pkval)
	{
	case 0x00: //enter
		point_enter();
		break;

	case 0x01://mirror
		if(BACK_point_mirror==0)
			BACK_point_mirror=1;
		else
			BACK_point_mirror=0;
		BACK_disp_angle=0xff;
		camset_eprom(DISABLE);
		break;

	case TKEY_EXIT:
		menu_display(NO_MENU,20);
		if(get_tcan_en()==1)
			TCAN_set(DISABLE);
		disp_cam_in();
		break;
	}
#endif
}



void cam_mode_set(u8 kid)
{
#ifndef __COMMIT_BY_LXL__
	u8 tmp;
	u8 osm[8];
	u16 dtmp[2];
	if(kid==12)  //del
	{
		if(offset_input_en==0)
		{
			if(pass_numid>0)
			{
				passward>>=4;
				pass_numid--;
				osd_offinput(6,osm);
			}
		}//offset_input_en==0

		else if((offset_input_en==1)||(offset_input_en==2))
		{
			if(pass_numid>0)
			{
				pass_numid--;
				BACK_dec_code_set>>=4;
				cam_chk_sum=osd_offset_num(pass_numid,offset_input_en-1);
			}
		}

		else if(offset_input_en==3)
		{
			if(pass_numid>0)
			{
				offset_tmp[0]>>=4;
				pass_numid--;
				cam_chk_sum=osd_offset_num(pass_numid,0);
			}
		}
		else if(offset_input_en==4)
		{
			if(pass_numid>0)
			{
				pass_numid=0;
				offset_tmp[1]=0;
				cam_chk_sum=osd_offset_num(pass_numid,1);
			} 		
		}
	}  //DEL
	else if(kid==11)   //ok
	{
		if(offset_input_en==0)
		{
			if((passward==CAM_PASSB)&&(pass_numid==4))
			{
				disp_point_menu();
			}
			else if((passward==CAM_PASSC)&&(pass_numid==4))
			{
				pass_numid=0;
				offset_input_en=1;
				offset_tmp[0]=0;
				offset_tmp[1]=0;
				osd_offinput(0,osm);
				cam_chk_sum=osd_offset_num(pass_numid,0);
			}
			else if((passward==CAM_PASSD)&&(pass_numid==4))
			{
				pass_numid=0;
				offset_input_en=3;
				offset_tmp[0]=0;
				osd_offinput(3,osm);
				cam_chk_sum=osd_offset_num(pass_numid,0);
			}
			osd_offinput(0xff,osm);	  
			pass_numid=0;
			passward=0;
		}
		else if(offset_input_en==1)
		{
			if(pass_numid==12)
			{
				pass_numid=0;
				offset_input_en=2;
				osd_offinput(1,osm);
				cam_chk_sum=osd_offset_num(pass_numid,1);
			}
			else
			{
				pass_numid=0;
				cam_chk_sum=osd_offset_num(pass_numid,0);
			} 

		}

		else if(offset_input_en==2)
		{
			dtmp[0]=((((offset_tmp[1]>>20)&0x0f)*100)+(((offset_tmp[1]>>16)&0x0f)*10)+((offset_tmp[1]>>12)&0x0f));
			dtmp[1]=((((offset_tmp[1]>>8)&0x0f)*100)+(((offset_tmp[1]>>4)&0x0f)*10)+(offset_tmp[1]&0x0f));
			if((pass_numid==12)&&(offset_tmp[0]==offset_tmp[1])&&(dtmp[0]<0xff)&&((dtmp[1]<0xff))
				&&(cam_sum==cam_chk_sum))
			{
				cam_xoffset=(u8)dtmp[0];
				cam_yoffset=(u8)dtmp[1];
				dec_code_TAB();
				camset_eprom(DISABLE);
				back_track_set();
				osd_offinput(2,osm);
				offset_input_en=0;
				pass_numid=0;
				offset_tmp[0]=0;
				offset_tmp[1]=0;
				back_track_mode_en=ENABLE;
				back_track_offset_send(cam_xoffset,cam_yoffset);
				delay(10000);
				menu_display(NO_MENU,1);
			}
			else
			{
				offset_input_en=1;
				pass_numid=0;
				cam_chk_sum=osd_offset_num(pass_numid,0);
				osd_offinput(5,osm);
				offset_tmp[0]=0;
				offset_tmp[1]=0;
			}

		}

		else if(offset_input_en==3)
		{
			if(pass_numid==4)
			{
				pass_numid=0;
				if((offset_tmp[0]&0xffff)<0xA000)
				{
					BACK_dec_code_set=(u16)(offset_tmp[0]&0xffff);
					offset_input_en=4;
					osd_offinput(4,osm);
					offset_tmp[1]=0;
					cam_chk_sum=osd_offset_num(pass_numid,1);
				}
				else
				{
					pass_numid=0;
					offset_tmp[0]=0;
					cam_chk_sum=osd_offset_num(pass_numid,0);
				}
			}
			else
			{
				pass_numid=0;
				offset_tmp[0]=0;
				cam_chk_sum=osd_offset_num(pass_numid,0);
			}
		}
		else if(offset_input_en==4)
		{
			if(pass_numid==1)
			{
				dec_code_TAB();
				back_track_offset_send(cam_xoffset,cam_yoffset);
				disp_offset_menu();
				cam_chk_sum=0;
			}
			else
			{
				pass_numid=0;
				offset_tmp[1]=0;
				cam_chk_sum=osd_offset_num(pass_numid,1);
			}
		}
	}
	else
	{
		if(kid<9)
			tmp=(kid+1);
		else
			tmp=0;

		if(offset_input_en==0)
		{
			if(pass_numid<4)
			{
				passward<<=4;
				passward|=tmp;
				pass_numid++;
				osd_offinput(6,osm);
			}
			else
			{
				pass_numid=0;
				passward=0;
				osd_offinput(0xff,osm);
			}
		}//offset_input_en==0

		else if((offset_input_en==1)||(offset_input_en==2))
		{
			if(pass_numid<12)
			{
				if(pass_numid==0)
				{
					BACK_dec_code_set=0;
					BACK_dec_code_set|=(tmp<<12);
				}
				else if(pass_numid==1)
				{
					BACK_dec_code_set|=(tmp<<8);
				}
				else if(pass_numid==2)
				{
					BACK_dec_code_set|=(tmp<<4);
				}
				else if(pass_numid==3)
				{
					BACK_dec_code_set|=(tmp);
				}
				else if(pass_numid==4)
				{
					if(tmp<8)
						cam_code=tmp;
				}

				else if(pass_numid==11)
				{
					cam_sum=tmp;
				}
				else
					offset_tmp[offset_input_en-1]|=(tmp<<((10-pass_numid)*4));

				pass_numid++;
				cam_chk_sum=osd_offset_num(pass_numid,offset_input_en-1);
			}
			else
			{
				pass_numid=0;
				if(offset_input_en==1)
				{
					offset_tmp[0]=0;
					cam_chk_sum=osd_offset_num(pass_numid,0);
				}
				else
				{
					offset_tmp[1]=0;
					cam_chk_sum=osd_offset_num(pass_numid,1);
				}
			}
		}

		else if(offset_input_en==3)
		{
			if(pass_numid<4)
			{
				offset_tmp[0]|=(tmp<<((3-pass_numid)*4));
				pass_numid++;
				cam_chk_sum=osd_offset_num(pass_numid,0);
			}
			else
			{
				pass_numid=0;
				offset_tmp[0]=0;
				cam_chk_sum=osd_offset_num(pass_numid,0);
			} 		
		}
		else if(offset_input_en==4)
		{
			if((pass_numid==0)&&(tmp<8))
			{
				offset_tmp[1]|=tmp;
				cam_code=tmp;
				pass_numid++;
				cam_chk_sum=osd_offset_num(pass_numid,1);
			}
			else
			{
				pass_numid=0;
				offset_tmp[1]=0;
				cam_chk_sum=osd_offset_num(pass_numid,1);
			} 		
		}
	}
#endif // end of 
}



u8 CAM_code_input(u8 *buff)
{

	u8 i;
	u8 tmp[16];
	for(i=0;i<12;i++)
	{
		//�ж��Ƿ���0~9֮��
#ifndef __COMMIT_BY_LXL__
		if((buff[3+i]>0x39)||(buff[3+i]<0x30))
			return(DISABLE);
		tmp[i]=(buff[3+i]&0x0f);
#else
		//����֡ͷ֮�������
		if((buff[i]>0x39)||(buff[i]<0x30))
			return(DISABLE);
		tmp[i]=(buff[i]&0x0f);
#endif
	}
#ifndef __COMMIT_BY_LXL__
	tmp[12]=0;
	for(i=0;i<11;i++)
	{
		tmp[12]+=tmp[i];
	}

	if(tmp[12]^tmp[11])
		return(DISABLE);
#endif

	for(i=0;i<4;i++)
	{
		BACK_dec_code_set<<=4;
		BACK_dec_code_set|=tmp[i];
	}
	cam_code=tmp[4];
	cam_xoffset=((tmp[5]*100)+(tmp[6]*10)+tmp[7]);
	cam_yoffset=((tmp[8]*100)+(tmp[9]*10)+tmp[10]);
	dec_code_TAB();
#ifndef __COMMIT_BY_LXL__
	camset_eprom(DISABLE);
#endif
	back_track_set();
	back_track_mode_en=ENABLE;
#ifdef __COMMIT_BY_LXL__
	Track_en = ENABLE;
#endif
	back_track_offset_send(cam_xoffset,cam_yoffset);
	return(ENABLE);
}


u8 osd_offset_num(u8 numid,u8 osdid)
{
#ifndef __COMMIT_BY_LXL__
	u8 osm[12];
	u8 m;
	u8 sum=0;
	for(m=0;m<12;m++)
		osm[m]='*';
	if((offset_input_en==1)||(offset_input_en==2))
	{ 
		for(m=0;m<numid;m++)
		{
			if(m==0)
				osm[0]=(((BACK_dec_code_set>>12)&0x0f)+0x30);
			else if(m==1)
				osm[1]=(((BACK_dec_code_set>>8)&0x0f)+0x30);
			else if(m==2)
				osm[2]=(((BACK_dec_code_set>>4)&0x0f)+0x30);
			else if(m==3)
				osm[3]=((BACK_dec_code_set&0x0f)+0x30);
			else if(m==4)
				osm[4]=((cam_code&0x07)+0x30);
			else
				osm[m]=(((offset_tmp[osdid]>>((10-m)*4))&0x0f)+0x30);
		}
		if(numid==12)
		{
			osm[11]=(cam_sum+0x30);
			for(m=0;m<11;m++)
				sum+=(osm[m]-0x30);
		}
		if(osdid==0)
			osd_offinput(7,osm);
		else
			osd_offinput(8,osm);

	}

	if(offset_input_en==3)
	{
		for(m=0;m<numid;m++)
			osm[m]=(((offset_tmp[0]>>((3-m)*4))&0x0f)+0x30);
		osd_offinput(9,osm);
	}

	if(offset_input_en==4)
	{
		if(numid==1)
			osm[0]=((offset_tmp[1]&0x0f)+0x30);

		osd_offinput(10,osm);
	}
	return(sum%10);
#else
	return 0;
#endif
}

extern void Tback_eeprom(u8 read_en,u8 *datval);
void camset_eprom(u8 mode)
{
#ifndef __COMMIT_BY_LXL__
	u8 crc;
	u8 m;
	u8 datmp[8];
	if(mode==DISABLE)
	{
		datmp[0]=cam_xoffset;
		datmp[1]=cam_yoffset;
		datmp[2]=BACK_angle_point;
		datmp[3]=BACK_angle_point_h;
		datmp[4]=((BACK_point_mirror<<7)|(get_tcan_en()<<6)|(cam_code&0x07));
		datmp[5]=BACK_dec_code;
		crc=0;
		for(m=0;m<6;m++)
			crc+=datmp[m];
		datmp[6]=crc;
		Tback_eeprom(DISABLE,datmp);
	}

	else 
	{
		Tback_eeprom(ENABLE,datmp);
		crc=0;
		for(m=0;m<6;m++)
			crc+=datmp[m];
		if(crc==datmp[6])
		{
			cam_xoffset=datmp[0];
			cam_yoffset=datmp[1];
			BACK_angle_point=datmp[2];
			BACK_angle_point_h=datmp[3];
			BACK_point_mirror=((datmp[4]>>7)&0x01);
			set_tcan_en((datmp[4]>>6)&0x01);
			BACK_dec_code=datmp[5];
			cam_code=(datmp[4]&0x07);
			back_track_mode_en=ENABLE;
			if((BACK_dec_code==7)||(BACK_dec_code==76)||(BACK_dec_code==101))
			{
				cam_xoffset=132;
				cam_yoffset=134;
			}
		}
		else
		{
			back_track_mode_en=DISABLE;
		}
	}
#endif
}


void point_enter(void)
{
#ifndef __COMMIT_BY_LXL__
	BACK_angle_point=BACK_angle_point_tmp;
	BACK_angle_point_h=BACK_angle_point_tmp_h;
	camset_eprom(DISABLE);
#endif
}

void back_track_set(void)
{
	BACK_wheel_max_angle=40;
	switch(BACK_dec_code)
	{
	case 0:	//�µ�A6L   //120-130
	case 8:	//maiteng
	case 10:	//��������
	case 11:	
	case 74:	
	case 17:
	case 21: //SENLINREN
	case 22: //kaixuan
	case 39: //REGAL
	case 40: //����;��
	case 99: //����Ե�10��
	case 78: //��˰�����
		BACK_fxp_max_angle=122;
		break;

	case 1:	//��������		//100-110
	case 88://������
	case 80://½��Ѳ��
	case 32://�ղ�����
	case 69://���ǿ���
	case 70://��������
	case 72://�׿���˹
	case 93://�������ö���
	case 98://������������
	case 19://�����ִ�IX35
	case 41://����350
	case 44://��������
	case 46://�µ���
	case 55://��������ʿ,MICRON
	case 68://�ղ��ô�
	case 71://�л�����
	case 73://�µ���09��
	case 81://����ʨ��
	case 89://������09��
	case 90://����������
	case 102://������ŷ
		BACK_fxp_max_angle=105;
		break;

	case 6:	//����	   //110-120
	case 4:	//Reiz
	case 15:
	case 59:
	case 14://�淶
	case 24://�ղ��п�
	case 42://���ǵ�F3
	case 45://�ɶ�
	case 49://������
	case 66://����S30
	case 67://�����ۺ�
	case 85://���ǵ�G3
		BACK_fxp_max_angle=115;
		break;


	case 9:	 //���Ӣ������	90-100
	case 12: //��ʤ
	case 13: //����						   
	case 16: //���Ӣ��
	case 23: //OCTAVIA
	case 60: //CRV
	case 26: //307
	case 27: //�ִ��ö�
	case 28: //��������
	case 30: //һ������
	case 31: //����A3
	case 34: // ������ӥ-1
	case 35: //С����
	case 36: //��ŵ���װ�
	case 37: //����
	case 43: //���⾢��
	case 82: //
	case 48: //˼��
	case 51://ѩ������³��,Micron
	case 52://��˾�Խ09,MICRON
	case 53://���Ǹ����,MICRON
	case 54://������,MICRON
	case 56://��������Ԧ
	case 57://09������,MICRON
	case 61://���ǵ�F6
	case 62://��ľ����
	case 75://�ִ�����
	case 84://����˹����
	case 86://��ľ�������
	case 95://����;��
	case 100://����˹����
	case 101://ŷ��������
		BACK_fxp_max_angle=95;
		break;

	case 50:  //Accord	 80-90
	case 77:  //����˼���
		BACK_fxp_max_angle=85;
		break;

	case 0xff:
		BACK_fxp_max_angle=BACK_new_dec_fxp_max;
		BACK_wheel_max_angle=BACK_new_dec_wheel_max;
		break;

	default:
		BACK_fxp_max_angle=120;
		BACK_wheel_max_angle=40;
		break;
	}
}

void TCAN_set(u8 onf)
{
	if(onf==ENABLE)
	{
		switch(BACK_dec_code)
		{
		case 74://�ʹ�	
			canid_val=CANID_CROWN;
			break;

		case 49: //CAROLLA	
		case 48: //YIZI	
			canid_val=CANID_CAROLLA;
			break;

		case 22: //KAIXUAN	
			canid_val=CANID_KAIXUAN;
			break;

		case 119: //KAIXUAN	
			canid_val=CANID_JEEP;
			break;

		case BACK_dec_code_val:	//121: //AUDI A4L	
			canid_val=CANID_A4L;
			break;

		case 25: //508	
			canid_val=CANID_BZ508;
			BACK_angle_point_h=0;
			BACK_angle_point=0;
			break;

		case 8: //MAGOTAN
		case 30://�µ�Q3	
			canid_val=CANID_MAGOTAN;
			break;

		case 20: //MAGOTAN_B&	
			canid_val=CANID_MAGOTAN_B7;
			break;

		case 15:	
		case 59:
			canid_val=CANID_REIZ;
			break;

		case 17: //Accord
		case 11: 	
			canid_val=CANID_ACCORD;
			break;

		case 21: //SENLINREN	
			canid_val=CANID_SENLINREN;
			break;

		case 33: //ѩ����C5
			canid_val=CANID_XIC5;
			break;

		case 18: //����
		case 37: //����
		case 47: //��ʨ
		case 82: //XV
		case 120: //˹��³ɭ����2013
			canid_val=CANID_AOHU;
			break;

		case 39://REGAL
			canid_val=CANID_REGAL;
			break;

		case 40://����;��
		case 5://˹�´����
			canid_val=CANID_TURUI;
			break; 

		case 43://���⾢��
			canid_val=CANID_JINXUAN;
			break;

		case 52://��˾�Խ09,MICRON
		case 16:	   //���Ӣ��
		case 9:
			canid_val=CANID_JUNYUE;
			break;

		case 72: //Lexus
		case 111:
			canid_val=CANID_LEXUS;
			break;


		case 78: //��˰�����
			canid_val=CANID_ANGKELEI;
			break;

		case 95://����;��
			canid_val=CANID_TUGUAN;
			break; 

		case 99://PRADO
			canid_val=CANID_PRADO;
			break; 

		case 0xff: //new	
#ifndef __COMMIT_BY_LXL__
			canid_val=NEW_CANID;
#endif
			break;
		}
#ifndef __COMMIT_BY_LXL__
		SEN_CAN_init();
#endif
	}
	else
	{
#ifndef __COMMIT_BY_LXL__
		CAN_IT_OFF();
#endif
	}
}

u16 get_BACK_canid_val(void)
{
	return(canid_val);
}

void set_CAN_Data(u8 data_num, u8 *rec_data)
{
	u8 m;
	for(m=0; m<data_num; m++)
	{
		if(m<data_num)
			CAN_angle_data[m]=rec_data[m];
	}
	CAN_data_flag=ENABLE;
}

void TData_Encode(u8 Can_h,u8 Can_l,u16 def_max,float Div_val,u8 dat_mode)
{
	u16 iSensorValue;
	u16 def_point;
	u16 def_angle;
	u8 iValue=0;

	if(dat_mode==0)
	{
		iSensorValue = Can_h << 8;
		iSensorValue |= Can_l;
		BACK_angle_point_tmp=Can_l;
		BACK_angle_point_tmp_h=Can_h;
		def_point=((BACK_angle_point_h<<8)+BACK_angle_point);
		if(iSensorValue<def_point)
		{	//Right
			def_angle=((def_point-iSensorValue)*Div_val);
			if(def_angle>BACK_wheel_max_angle)//left
			{
				def_angle=(((def_max-def_point)+iSensorValue)*Div_val);
				iValue=(u8)def_angle;
				if(iValue>BACK_wheel_max_angle)
					iValue=BACK_wheel_max_angle;
				iValue|=0x80;
			}
			else  //normal right
			{
				iValue=(u8)def_angle;
			}
		}
		else	//Left
		{
			def_angle=((iSensorValue-def_point)*Div_val);
			if(def_angle>BACK_wheel_max_angle) //right
			{
				def_angle=(((def_max-iSensorValue)+def_point)*Div_val);
				iValue=(u8)def_angle;
				if(iValue>BACK_wheel_max_angle)
					iValue=BACK_wheel_max_angle;
			}
			else  //normal left
			{
				iValue=((u8)def_angle+0x80);
			}
		}
	}

	else if(dat_mode==1)	//dat_mode==1
	{
		iSensorValue = (Can_h << 8);
		iSensorValue |= Can_l;
		iSensorValue &= 0x7FFF;
		iSensorValue >>= 5;	//������3λ
		if(Can_h & 0x80)
		{	//Right
			iValue = (u8)(iSensorValue*Div_val);
			BACK_angle_point_tmp=iValue;
			if(BACK_angle_point&0x80)
				iValue+=(BACK_angle_point&0x7f);
			else
				iValue-=BACK_angle_point;

			if(iValue>BACK_wheel_max_angle)
				iValue=BACK_wheel_max_angle;
		}
		else	//Left
		{
			iValue = ((u8)((iSensorValue)*Div_val))|0x80;
			BACK_angle_point_tmp=iValue;
			if(BACK_angle_point&0x80)
				iValue-=(BACK_angle_point&0x7f);
			else
				iValue+=BACK_angle_point;
			if(iValue>(0x80+BACK_wheel_max_angle))
				iValue=(0x80+BACK_wheel_max_angle);
		}
	}

	else if(dat_mode==3)
	{
		iSensorValue = (Can_h  << 8);
		iSensorValue |= Can_l ;
		BACK_angle_point_tmp=Can_l;
		BACK_angle_point_tmp_h=Can_h;
		def_point=((BACK_angle_point_h<<8)+BACK_angle_point);
		if(iSensorValue<def_point)
		{	//Right
			def_angle=((def_point-iSensorValue)*Div_val);
			if(def_angle>BACK_wheel_max_angle)
			{
				iValue=(u8)def_angle;
				if(iValue>BACK_wheel_max_angle)
					iValue=BACK_wheel_max_angle;
			}
			else  //normal right
			{
				iValue=(u8)def_angle;
			}
		}
		else	//Left
		{
			def_angle=((iSensorValue-def_point)*Div_val);
			if(def_angle>BACK_wheel_max_angle) //right
			{
				iValue=(u8)def_angle;
				if(iValue>BACK_wheel_max_angle)
					iValue=BACK_wheel_max_angle;
				iValue=((u8)def_angle+0x80);
			}
			else  //normal left
			{
				iValue=((u8)def_angle+0x80);
			}
		}
	}

	else if(dat_mode==4)  //A4L	ljh+
	{
		iSensorValue = (Can_h << 8);
		iSensorValue |= Can_l;
		iSensorValue&=0x1FFF;
		if(Can_h & 0x20)
		{	//Right
			iValue = (u8)(iSensorValue*Div_val);
			BACK_angle_point_tmp=iValue;
			if(iValue>BACK_wheel_max_angle)
				iValue=BACK_wheel_max_angle;
		}
		else	//Left
		{
			iValue = ((u8)((iSensorValue)*Div_val))|0x80;
			BACK_angle_point_tmp=iValue;
			if(iValue>(0x80+BACK_wheel_max_angle))
				iValue=(0x80+BACK_wheel_max_angle);
		}
	}
	else if(dat_mode==5)  //Q3	ljh+
	{
		iSensorValue = (Can_h << 8);
		iSensorValue |= Can_l;
		iSensorValue&=0x3FFF;
		if(Can_h & 0x80)
		{	//Right
			iValue = (u8)(iSensorValue*Div_val);
			BACK_angle_point_tmp=iValue;
			if(iValue>BACK_wheel_max_angle)
				iValue=BACK_wheel_max_angle;
		}
		else	//Left
		{
			iValue = ((u8)((iSensorValue)*Div_val))|0x80;
			BACK_angle_point_tmp=iValue;
			if(iValue>(0x80+BACK_wheel_max_angle))
				iValue=(0x80+BACK_wheel_max_angle);
		}
	}


	if(iValue==0x80)
		iValue=0;

	BACK_wheel_angle=iValue;
	if(BACK_wheel_angle^BACK_disp_angle)
		BACK_angle_send_en=ENABLE;
}


void TData_Task(void)
{

	if((CAN_data_flag==DISABLE)||(Track_en==DISABLE))
		return;

	CAN_data_flag=DISABLE;

	switch(BACK_dec_code)
	{
	case 74:  //Crown
		TData_Encode(CAN_angle_data[0],CAN_angle_data[1],0x0fff,CROWN_DIV,0);
		break;

	case 49:  //Carolla
		TData_Encode(CAN_angle_data[0],CAN_angle_data[1],0x0fff,CAROLLA_DIV,0);
		break; 

	case 48:  //YIZI
		TData_Encode(CAN_angle_data[0],CAN_angle_data[1],0x0fff,YIZI_DIV,0);
		break; 

	case 22://Kaixuan
		TData_Encode(CAN_angle_data[0],CAN_angle_data[1],0xffff,KAIXUAN_DIV,0);
		break;

	case 25://508
		TData_Encode(CAN_angle_data[0],CAN_angle_data[1],0xffff,BZ508_DIV,0);
		break;

	case 8:	//Magotan
		TData_Encode(CAN_angle_data[1],CAN_angle_data[0],0xffff,MAGOTAN_DIV,5);
		break;
	case 30://�µ�Q3	//ljh_chg
		TData_Encode(CAN_angle_data[1],CAN_angle_data[0],0xffff,0.00471087f,5);
		break;

	case 20:	//Magotan_B7
		TData_Encode(CAN_angle_data[1],CAN_angle_data[0],0xffff,MAGOTAN_B7_DIV,1);
		break;

	case 15:
	case 59:
		TData_Encode(CAN_angle_data[0],CAN_angle_data[1],0x0fff,REIZ_DIV,0);
		break;

	case 17:
	case 11:  
		TData_Encode(CAN_angle_data[2],CAN_angle_data[3],0xffff,ACCORD_DIV,0);
		break;

	case 21:
		TData_Encode(CAN_angle_data[1],CAN_angle_data[0],0xffff,SENLINREN_DIV,0);
		break;

	case 33:
		TData_Encode(CAN_angle_data[0],CAN_angle_data[1],0xffff,XIC5_DIV,0);
		break;

	case 37:
	case 18: //����
	case 82: //XV
	case 120: //˹��³ɭ����2013
		TData_Encode(CAN_angle_data[0],CAN_angle_data[1],0xffff,AOHU_DIV,0);
		break;

	case BACK_dec_code_val:	//121://A4L
		TData_Encode(CAN_angle_data[3],CAN_angle_data[2],0xffff,AOHU_DIV,4);
		break;

	case 47:
		TData_Encode(CAN_angle_data[0],CAN_angle_data[1],0xffff,LISHI_DIV,0);
		break;

	case 39:
		TData_Encode(CAN_angle_data[1],CAN_angle_data[2],0xffff,REGAL_DIV,0);
		break;

	case 40:
	case 5:
		TData_Encode(CAN_angle_data[1],CAN_angle_data[0],0xffff,TURUI_DIV,1);
		break;

	case 43:
		TData_Encode(CAN_angle_data[0],CAN_angle_data[1],0xffff,JINXUAN_DIV,3);
		break;

	case 52:
	case 16:	   //���Ӣ��
	case 9:	   //���Ӣ��
		TData_Encode(CAN_angle_data[1],CAN_angle_data[2],0xffff,JUNYUE_DIV,0);
		break;

	case 72:
	case 111:
		TData_Encode(CAN_angle_data[0],CAN_angle_data[1],0x0fff,LEXUS_DIV,0);
		break;

	case 78:
		TData_Encode(CAN_angle_data[1],CAN_angle_data[2],0xffff,ANGKELEI_DIV,0);
		break;

	case 95:
		TData_Encode(CAN_angle_data[1],CAN_angle_data[0],0xffff,TUGUAN_DIV,1);
		break;

	case 99:
		TData_Encode(CAN_angle_data[0],CAN_angle_data[1],0x0fff,PRADO_DIV,0);
		break;

	case 119:
		TData_Encode(CAN_angle_data[4],CAN_angle_data[5],0x0fff,JEEP_DIV,0);
		break;

	case 0xff:	
#ifndef __COMMIT_BY_LXL__
		TData_NEW_Encode(CAN_angle_data);
#endif
		break;	
	default:
		break;
	}
}



void set_t_dat_num(u8 sval)
{
	t_dat_num=sval;
}

void Tback_dec_init(void)
{
#ifndef __COMMIT_BY_LXL__
	if(NEW_DEC_CODE==0xff)
		BACK_dec_code=NEW_DEC_CODE;
	back_track_offset_send(cam_xoffset,cam_yoffset);
	offset_input_en=0;
	TIM_ITConfig(TIM2, TIM_IT_CC2, DISABLE);
	Cam_ID_Chk();
	if(get_tcan_en()==1)
		TCAN_set(ENABLE);
	else
		TIM4_CAP_IN_SET();
#endif
}

u16 disp_cont;
u8 get_angle_send_en(void)
{
	if((BACK_dec_code==7)||(BACK_dec_code==76)||(BACK_dec_code==101))
	{
		disp_cont++;
		if(disp_cont>5)
		{
			disp_cont=0;
			BACK_wheel_angle=0;
			return(ENABLE);
		}   
	}
	return(BACK_angle_send_en);
}

u8 get_offset_input_en(void)
{
	return(offset_input_en);
}

u8 get_track_en(void)
{
	return(Track_en);
}

u8 get_wheel_angle(void)
{
	if(Track_en==ENABLE)
		return(BACK_wheel_angle);
	else
		return(0);
}

void U8_To_DEC_OSD(u8 *strtmp, u8 numval1,u8 numval2)
{
	strtmp[5]=((numval1/100)+0x30);
	numval1%=100;
	strtmp[6]=((numval1/10)+0x30);
	numval1%=10;
	strtmp[7]=(numval1+0x30);
	strtmp[8]=((numval2/100)+0x30);
	numval2%=100;
	strtmp[9]=((numval2/10)+0x30);
	numval2%=10;
	strtmp[10]=(numval2+0x30);
}

void get_offset_osd(u8 *sdata)
{
	u8 sum=0;
	u8 m;
	u8 osm[12];
	sdata[0]=(((BACK_dec_code_set>>12)&0x0f)+0x30);
	sdata[1]=(((BACK_dec_code_set>>8)&0x0f)+0x30);
	sdata[2]=(((BACK_dec_code_set>>4)&0x0f)+0x30);
	sdata[3]=((BACK_dec_code_set&0x0f)+0x30);
	sdata[4]=((cam_code&0x07)+0x30);  
	U8_To_DEC_OSD(osm, cam_xoffset_tmp,cam_yoffset_tmp);
	for(m=5;m<11;m++)
		sdata[m]=osm[m]; 
	for(m=0;m<11;m++)
		sum+=(sdata[m]-0x30);
	sdata[11]=((sum%10)+0x30);
	cam_sum=(sdata[11]-0x30);
}

void tback_track_init(void)
{
#ifndef __COMMIT_BY_LXL__
	if(get_T_back_cam_en()==ENABLE)
		back_track_offset_send(cam_xoffset,cam_yoffset);
	BACK_angle_send_en=DISABLE;
	BACK_disp_angle=0xff;
#endif
}

void set_disp_angle(u8 sval)
{
	BACK_disp_angle=sval;
}

void offset_init(void)
{
	offset_input_en=0;
	pass_numid=0;
	passward=0;
}

#ifdef __COMMIT_BY_LXL__
void SetCameraCode(u8 *buff)
{
	//Ҫ�Ȱ����ݴ���һ��

	CAM_code_input(buff);
}
#endif