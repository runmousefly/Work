#include "stdafx.h"
#include "CamTrack.h"

#define  MAX_TRACK_BUF_SIZE 200
#define  MAX_OFFSET_X 120
#define  MAX_OFFSET_Y 100

#define  ANGLE_RANGE_40_40  1
#define  ANGLE_RANGE_127_127 0  //D107E�ķ�ʽ127����0��

Track::Track(void) : pTrackData(NULL), pStopLineData(NULL), hBinFile(NULL), OldAngleIndex(0),
MaxAngle(0), MinAngle(0), AngIndex(0), m_curAngle(0), m_nTrackSettingMode(TRACK_MODE_NOTHING),
m_bModeShowZero(TRUE)
{
	m_hwnd			= NULL;
	m_funSendData   = NULL;
	m_renderclass   = NULL;
	m_scalex	    = m_scaley  = 1.0f;
	IsTrackInLeft   = IsTrackInRight =FALSE;
	pTrackData		= new char[MAX_TRACK_BUF_SIZE];
	pStopLineData	= new char[MAX_TRACK_BUF_SIZE];
	if (pStopLineData == NULL)
	{
		fwprintf(stderr,L"_____lxl_____can not new any data!!!!!!!!\n");
	}
	hBinFile		= INVALID_HANDLE_VALUE;
	for (int nSize = 0; nSize < MAX_LINE_NUM;nSize ++){
		m_pArray[nSize]  = NULL;
	}
	ZeroMemory(m_szBufTrackPoint_path,sizeof(m_szBufTrackPoint_path));
	ZeroMemory(m_szBufTrackPoint_index_path,sizeof(m_szBufTrackPoint_index_path));
}

Track::~Track(void)
{
	UnInit();
}

bool Track::OpenTrackData() 
{
	if (m_szBufTrackPoint_path[0] != 0)
	{
		hBinFile=::CreateFile(m_szBufTrackPoint_path,	\
			GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if(hBinFile==INVALID_HANDLE_VALUE
			||hBinFile == NULL){
			fwprintf(stderr,L"__________lxl____________Load bin file failed\n");
			return false;
		}
		return true;
	}
	return false;
}

void Track::InitTrack(HWND hwnd)
{
	m_hwnd = hwnd;
	OpenTrackData();
	ReadTrackPointIndex();
	GetTrackBackInfo();
}

void Track::InitTrack(FunTrackDataBack pcallback,LPVOID lpclass)
{
	m_funSendData = pcallback;
	m_renderclass = lpclass;
	OpenTrackData();
	ReadTrackPointIndex();
	GetTrackBackInfo();
}

void Track::InitFilePaths(LPCTSTR lpstrIndex,LPCTSTR lpstrData)
{
	memcpy(m_szBufTrackPoint_index_path,lpstrIndex,wcslen(lpstrIndex)*sizeof(TCHAR));
	memcpy(m_szBufTrackPoint_path,lpstrData,wcslen(lpstrData)*sizeof(TCHAR));
}

void Track::UnInit()
{
	fwprintf(stderr,L"_________lxl______Track::UnInit()\n");
	m_hwnd		  = NULL;
	m_renderclass = NULL;
	m_funSendData = NULL;
	if (hBinFile){
		CloseHandle(hBinFile);
		hBinFile = NULL;
	}
	if(pTrackData){
		delete [] pTrackData; pTrackData = NULL;
	}
	if (pStopLineData)
	{
		delete [] pStopLineData; pStopLineData = NULL;
	}
	for (int nSize = 0; nSize < MAX_LINE_NUM;nSize ++)
	{
		if (m_pArray[nSize])
		{
			delete[] m_pArray[nSize];
			m_pArray[nSize] = NULL;
		}
	}
}

BOOL Track::ReadTrackData( int AngIndex,char *pInPutBuffer )
{
	BOOL ret=FALSE;
	DWORD dwOffset=2000+100*200*m_Camsaveinfo.iCM_Type+(54+AngIndex)*200L;
	DWORD dwWrite=200;
	DWORD Bytesread=0;
	SetFilePointer(hBinFile, dwOffset, NULL, FILE_BEGIN); 
	ReadFile(hBinFile,pInPutBuffer,dwWrite,&Bytesread,NULL);
	if(Bytesread>0) ret=TRUE;
	return ret;
}

BOOL Track::ReadAngle( int *maxangle,int *minangle )
{
	BOOL ret=FALSE;
	if((maxangle==NULL)||(minangle==NULL))
		return ret;
	DWORD dwOffset=2000+100*200*m_Camsaveinfo.iCM_Type+7*200L;
	DWORD dwWrite=200;
	DWORD Bytesread=0;
	char pInPutBuffer[200];
	SetFilePointer(hBinFile, dwOffset, NULL, FILE_BEGIN); 
	ReadFile(hBinFile,pInPutBuffer,dwWrite,&Bytesread,NULL);
	*maxangle=pInPutBuffer[0];
	*minangle=pInPutBuffer[1];
	if(Bytesread>0) 
		ret=TRUE;
	return ret;
}

BOOL Track::ReadStopLineData( int LineNO,char *pInPutBuffer)
{
	BOOL ret=FALSE;
	if ((LineNO>6)||(LineNO<0))
		return ret;
	DWORD dwOffset=2000+100*200*m_Camsaveinfo.iCM_Type+LineNO*200L;
	DWORD dwWrite=200;
	DWORD Bytesread=0;
	SetFilePointer(hBinFile, dwOffset, NULL, FILE_BEGIN); 
	ReadFile(hBinFile,pInPutBuffer,dwWrite,&Bytesread,NULL);
	if(Bytesread>0) ret=TRUE;
	return ret;
}
//////////////////////////////////////////////////////////////////////////
//by lxl
#define START_CHAR '0'
void Track::CalcCamIDCode() 
{
	int nIndex =  FindCamerinfoByCMType(m_Camsaveinfo.iCM_Type);
	if(nIndex != -1)
	{
		int cam=m_CamerainfoAll.at(nIndex).icamcode;
		int camverify=cam/10000+(cam%10000)/1000+((cam%10000)%1000)/100+(((cam%10000)%1000)%100)/10+(((cam%10000)%1000)%100)%10;
		int x100,x10,x1;
		int y100,y10,y1;
		x100=m_Camsaveinfo.iTrack_x/100;
		x10=(m_Camsaveinfo.iTrack_x%100)/10;
		x1=(m_Camsaveinfo.iTrack_x%100)%10;
		y100=m_Camsaveinfo.iTrack_y/100;
		y10=(m_Camsaveinfo.iTrack_y%100)/10;
		y1=(m_Camsaveinfo.iTrack_y%100)%10;
		int verify=(x100+x10+x1+y100+y10+y1+camverify)%10;
		camera_code[0] = cam/10000+START_CHAR;
		camera_code[1] = (cam%10000)/1000+START_CHAR;	
		camera_code[2] = (cam%1000)/100+START_CHAR;	
		camera_code[3] = (cam%100)/10+START_CHAR;	
		camera_code[4] = cam%10+START_CHAR;
		camera_code[5] = x100+START_CHAR;
		camera_code[6] = x10+START_CHAR;
		camera_code[7] = x1+START_CHAR;
		camera_code[8] = y100+START_CHAR;
		camera_code[9] = y10+START_CHAR;
		camera_code[10] = y1+START_CHAR;
		camera_code[11] = verify+START_CHAR;	
		if (IsTrackOK())
		{
			if (m_hwnd)
			{
				COPYDATASTRUCT cp;
				cp.cbData = sizeof(camera_code);
				cp.lpData = camera_code;
				::SendMessage(m_hwnd,WM_COPYDATA,TRACK_TYPE_ID_DATA,(LPARAM)&cp);
			}
			if (m_funSendData)
			{
				m_funSendData(TRACK_TYPE_ID_DATA,(LPVOID)camera_code,m_renderclass);
			}
		}
	}
}

void Track::SaveTrackBackInfo()
{
	//��mcu�����������
	CalcCamIDCode();
}
//HQ10���ô������ȡ��,���ǽӿڻ��������Ű�
void Track::GetTrackBackInfo()
{

}

void Track::CorrectAngleIndex() 
{
#if ANGLE_RANGE_127_127
	if((AngIndex>=MinAngle)&&(AngIndex<0)&&(IsTrackInLeft==FALSE)&&(IsTrackInRight==FALSE))
	{
		IsTrackInLeft=TRUE;
		OldAngleIndex=AngIndex; 
	}
	else if(IsTrackInLeft)
	{
		if((AngIndex>=0))
		{  
			IsTrackInLeft=FALSE;
			IsTrackInRight=TRUE;
			OldAngleIndex=AngIndex; 
		}
		else if((AngIndex>=MinAngle)&&(AngIndex<=0))
		{
			OldAngleIndex=AngIndex; 
		}
		else
		{
			OldAngleIndex=MinAngle;
		}
	}
	else if((AngIndex>0)&&(AngIndex<=MaxAngle)&&(IsTrackInLeft==FALSE)&&(IsTrackInRight==FALSE))
	{ 
		IsTrackInRight=TRUE;
		OldAngleIndex=AngIndex; 
	}
	else if(IsTrackInRight)
	{ 
		if((AngIndex<=0))
		{ 
			IsTrackInRight=FALSE;
			IsTrackInLeft=TRUE;
			OldAngleIndex=AngIndex; 
		}
		else if((AngIndex>=0)&&(AngIndex<=MaxAngle))
		{
			OldAngleIndex=AngIndex; 
		}
		else
			OldAngleIndex=MaxAngle;
	}
#endif
	if(m_Camsaveinfo.iLen_Type)//reverse
	{
		OldAngleIndex=-OldAngleIndex;
	}
}

void Track::BuildCommonLineData(int nIndex,char *pBuf)
{
	//fwprintf(stderr,L"==============Track::BuildCommonLineData start %d,%x\n",nIndex,pBuf);
	int	   n = 0;
	short  *pShort;
	char   cTmp[4];
	if (!pBuf)
	{
		fwprintf(stderr,L"==============Track::BuildCommonLineData pBuf empty\n");
		return ;
	}
	//����
	short Number=pBuf[1];

	if (m_pArray[nIndex])
	{
		//fwprintf(stderr,L"==============Track::BuildCommonLineData delete[] m_pArray[nIndex] start\n");
		delete[] m_pArray[nIndex];
		//fwprintf(stderr,L"==============Track::BuildCommonLineData delete[] m_pArray[nIndex] end\n");
	}
	if (Number > MAX_TRACK_POINT)
	{
		return;
	}
	m_pArray[nIndex]= new Co_Point[Number];
	//fwprintf(stderr,L"==============Track::BuildCommonLineData new Co_Point[Number] ok \n");

	int  nOffsetX = (int)(m_Camsaveinfo.iTrack_x*m_scalex)-OffsetX4Correct();//�ֶ�������ʱ��Ҫ����һ�������ƫ��
	int  nOffsetY = (int)(m_Camsaveinfo.iTrack_y*m_scaley)-OffsetY4Correct();

	//fwprintf(stderr,L"==============Track::BuildCommonLineData clac start %d\n");
	cTmp[0]=pBuf[3];
	cTmp[1]=pBuf[2];
	pShort=(short *)(char *)&cTmp[0];
	m_pArray[nIndex][0].x=(*pShort)*m_scalex+nOffsetX;
	cTmp[0]=pBuf[5];
	cTmp[1]=pBuf[4];
	pShort=(short *)(char *)&cTmp[0];
	m_pArray[nIndex][0].y=(*pShort)*m_scaley+nOffsetY;
	//fwprintf(stderr,L"==============Track::BuildCommonLineData clac end\n");

	//fwprintf(stderr,L"==============Track::BuildCommonLineData clac %d array start\n",Number);
	for(n=1; n<Number; n++)
	{
		m_pArray[nIndex][n].x=(pBuf[4+n*2])*m_scalex;
		m_pArray[nIndex][n].y=(pBuf[5+n*2])*m_scaley;
	}
	//fwprintf(stderr,L"==============Track::BuildCommonLineData clac array end\n");
	SendTrackData(nIndex,m_pArray[nIndex],Number);
}

void Track::BuildTrackData(char* pBuf)
{
	BuildCommonLineData(MAX_LINE_NUM-1,pBuf);
}

void Track::UpdateTrack()
{
	CAMERAINFO* pInfo = GetCurrentCameraInfo();
	if (!pInfo)
		return ;
	MaxAngle=pInfo->angle;
	MinAngle=-pInfo->angle;
#if ANGLE_RANGE_40_40
#else // ANGLE_RANGE_127_127
	AngIndex=GetCurrentAngleIndex(m_curAngle,m_Camsaveinfo.bZE_Angle,pInfo->offset,pInfo->angle);
#endif
	CorrectAngleIndex();
	if(GetTrackSettingMode()==TRACK_MODE_SETTING)
	{
		for(int i=0;i<MAX_LINE_NUM-1;i++)
		{
			ReadStopLineData(i,pStopLineData); //��ȡ�����
			BuildCommonLineData(i,pStopLineData);
		}
	}
	else if((GetTrackSettingMode()==TRACK_MODE_NORMAL))
	{
		if (m_bModeShowZero)
		{
			for(int i=0;i<MAX_LINE_NUM-1;i++) //����ߵ�7���ߣ���������
			{
				ReadStopLineData(i,pStopLineData); 
				BuildCommonLineData(i,pStopLineData);
			}
		}
		ReadTrackData(OldAngleIndex,pTrackData);
		BuildTrackData(pTrackData);
	}  
}
#define  MAX_ANGLE  127
int Track::GetCurrentAngleIndex( int tempangle,int zeroangle,int maxoffset,int maxangle )
{
	int currentindex=90;
	int tempoffset=0;
	tempoffset=abs(tempangle-zeroangle);
	if(tempoffset>MAX_ANGLE){
		tempoffset=255-tempoffset;
	}

	if(tempoffset>=maxoffset){
		currentindex=maxangle;
	}
	else{
		//107E��MCU�ϴ��ĽǶ����ݷ�Χ��0~255,���������Ӧ��Ӱ��
		currentindex=(tempoffset*maxangle+maxoffset/2)/maxoffset;
	}
	if(zeroangle>=MAX_ANGLE)
	{
		if((tempangle>=(zeroangle-MAX_ANGLE))&&(tempangle<=zeroangle))  //in left region
		{
			currentindex =-abs(currentindex);
		}
		else // in right region
		{
			currentindex =abs(currentindex);
		}
	}
	else
	{
		if((tempangle>=zeroangle)&&(tempangle<=(zeroangle+MAX_ANGLE)))
		{
			currentindex =-abs(currentindex);
		}
		else
			currentindex =abs(currentindex);
	}

	return currentindex;
}


int  FindFirstDataAt(TCHAR* pdatasrc,int ndatalen,TCHAR target){

	int nIndex = -1;
	for (int nSize = 0;nSize < ndatalen;nSize++)
	{
		if (pdatasrc[nSize] == target)
		{
			nIndex = nSize;
			break;
		}
	}
	return nIndex;
}

bool Track::ReadTrackPointIndex()
{
	HANDLE hFile = CreateFile(m_szBufTrackPoint_index_path, GENERIC_READ|GENERIC_WRITE,// Access (read-write) mode
		0,            // Share mode
		NULL,         // Pointer to the security attribute
		OPEN_EXISTING,// How to open the 
		0,            // Port attributes
		NULL);        // Handle to port with attribute to copy
	if(!ISVALIDHANDLE(hFile))
	{
		fwprintf(stderr,L"__________lxl____________Track::ReadTrackPointIndex failed\n");
		return false;
	}
	while(ISVALIDHANDLE(hFile))
	{
		DWORD dwSize = GetFileSize(hFile,NULL);
		TCHAR* pTemp = new TCHAR[dwSize];
		if (!pTemp){
			break;
		}
		DWORD dwRead = 0;
		ReadFile(hFile, pTemp, dwSize*sizeof(TCHAR), &dwRead, NULL);

		if (!dwRead)
			break;
		TCHAR  cs_comma=L',';
		TCHAR  cs_comma2=L';';
		TCHAR  cs_bufIndex[12]={0};
		TCHAR*  szBuf  = pTemp;
		CAMERAINFO  tempcamerinfo;
		for (int i =0;i < CAMERA_NUMBER;i++)
		{
			int nIndexLen  = swprintf_s(cs_bufIndex,12,L"%d=",i);
			TCHAR* pStart =wcsstr(szBuf,cs_bufIndex);
			if (pStart ==NULL){
				if (szBuf < pTemp+dwRead){
					continue;
				}
				break;
			}
			tempcamerinfo.nIndex = i;
			szBuf = pStart;
			int nEndPos= FindFirstDataAt(szBuf,(dwRead-(pTemp-szBuf)),cs_comma);
			memset(tempcamerinfo.camcode,0,sizeof(tempcamerinfo.camcode));
			memcpy(tempcamerinfo.camcode,szBuf+nIndexLen,(nEndPos-nIndexLen)*sizeof(TCHAR));
			tempcamerinfo.icamcode = _wtoi(tempcamerinfo.camcode);
			szBuf+=(nEndPos+1);
			//get the angle and offset.
			nEndPos    = FindFirstDataAt(szBuf,(dwRead-(pTemp-szBuf)),cs_comma);
			TCHAR   szAngle[32] ={0};
			memcpy(szAngle,szBuf,nEndPos*sizeof(TCHAR));
			tempcamerinfo.angle = _wtoi(szAngle);
			szBuf+=(nEndPos+1);
			nEndPos    = FindFirstDataAt(szBuf,(dwRead-(pTemp-szBuf)),cs_comma2);
			ZeroMemory(szAngle,sizeof(szAngle));
			memcpy(szAngle,szBuf,nEndPos*sizeof(TCHAR));
			tempcamerinfo.offset = _wtoi(szAngle);
			szBuf+=(nEndPos+1);
			//get the name
			nEndPos  = FindFirstDataAt(szBuf,(dwRead-(szBuf-pTemp)),L'/');
			memset(tempcamerinfo.deviceName,0,sizeof(tempcamerinfo.deviceName));
			memcpy(tempcamerinfo.deviceName,szBuf,nEndPos*sizeof(TCHAR));
			szBuf+=(nEndPos);
			m_CamerainfoAll.push_back(tempcamerinfo);
		}
		delete[] pTemp;
		pTemp = NULL;
		break;
	}

	if (ISVALIDHANDLE(hFile))
	{
		SetEndOfFile(hFile);
		CloseHandle(hFile);
		hFile = NULL;
	}
	return true;
}

bool Track::SetCurrentAngle(int nCurAngle)
{
#if ANGLE_RANGE_40_40
	if (abs(nCurAngle) > 40)
	{
		return false;
	}
	m_curAngle  = nCurAngle;
	OldAngleIndex = m_curAngle;
#else
	m_curAngle  = nCurAngle;
#endif
	UpdateTrack();
	return true;
}

bool Track::SetCurrentAngle(UCHAR* pdata,int nNum)
{
	if (pdata == 0 ||nNum == 0)
	{
		return false;
	}
	set_CAN_Data(nNum,pdata);
	TData_Task();
	m_curAngle = get_wheel_angle();
	if (m_curAngle>127)
	{
		m_curAngle= 127-m_curAngle;
	}
	OldAngleIndex = m_curAngle;
	UpdateTrack();
	return true;
}

//////////////////////////////////////////////////////////////////////////
int  Track::FindCamerinfoByCMType(int nIndex)
{
	int nResult = -1;
	for (size_t nsize = 0;nsize < m_CamerainfoAll.size();nsize++)
	{
		if(m_CamerainfoAll.at(nsize).nIndex == nIndex)
		{
			nResult = nsize;
		}
	}
	return nResult;
}
bool Track::SetTrackCode(int nCamCode,bool bUpdateTrack /*= true*/)
{
	for (size_t nsize = 0;nsize < m_CamerainfoAll.size();nsize++)
	{
		if(m_CamerainfoAll.at(nsize).icamcode == nCamCode)
		{
			ResetTrackVar();
			m_Camsaveinfo.iCM_Type = (int)nsize;
			//�����ַ���ȥ
			CAMERAINFO* pInfo = GetCurrentCameraInfo();
			if (pInfo)
			{
				if (m_hwnd)
				{
					COPYDATASTRUCT cp;
					cp.cbData = wcslen(pInfo->deviceName);
					cp.lpData = pInfo->deviceName;
					::SendMessage(m_hwnd,WM_COPYDATA,TRACK_TYPE_CAR_NAME,(LPARAM)&cp);
				}
				if(m_funSendData)
					m_funSendData(TRACK_TYPE_CAR_NAME,(LPVOID)pInfo->deviceName,m_renderclass);
			}
			if (bUpdateTrack){
				UpdateTrack();
			}
			return true;
		}
	}
	return false;
}

void Track::ResetTrackVar()
{
	IsTrackInLeft=FALSE;
	IsTrackInRight=FALSE;
	AngIndex=0;
	OldAngleIndex=0;
	m_Camsaveinfo.iTrack_x =0;
	m_Camsaveinfo.iTrack_y =0;
	SetTrackSettingMode(TRACK_MODE_SETTING,true);
}


void Track::OffsetTrack(int nX,int nY)
{
	m_Camsaveinfo.iTrack_x += nX;
	if (m_Camsaveinfo.iTrack_x < 0)
	{
		m_Camsaveinfo.iTrack_x = 0;
	}
	m_Camsaveinfo.iTrack_y += nY;
	if (m_Camsaveinfo.iTrack_y <0)
	{
		m_Camsaveinfo.iTrack_y = 0;
	}
	CalcCamIDCode();
	UpdateTrack();
}

CAMERAINFO* Track::GetCurrentCameraInfo()
{
	int nIndex = FindCamerinfoByCMType(m_Camsaveinfo.iCM_Type);
	if (nIndex != -1)
	{
		return &m_CamerainfoAll.at(nIndex);
	}
	return NULL;
}

int  Track::GetTrackCode()
{
	int nCode = -1;
	CAMERAINFO* pData = GetCurrentCameraInfo();
	if (pData)
	{
		return pData->icamcode;
	}
	return nCode;
}

//////////////////////////////////////////////////////////////////////////
#define BYTE2NUM(X) ((X)-'0')
bool Track::SetCameraID(CAMERA_IDENTIFY_ID *pData)
{
	//����У����û����
	BYTE* pByte = pData->bIDData;
	SetTrackCode(BYTE2NUM(pByte[0])*10000+BYTE2NUM(pByte[1])*1000+BYTE2NUM(pByte[2])*100+BYTE2NUM(pByte[3])*10+BYTE2NUM(pByte[4]),false);
	m_Camsaveinfo.iTrack_x = BYTE2NUM(pByte[5])*100+BYTE2NUM(pByte[6])*10+BYTE2NUM(pByte[7]);
	m_Camsaveinfo.iTrack_y = BYTE2NUM(pByte[8])*100+BYTE2NUM(pByte[9])*10+BYTE2NUM(pByte[10]);
	m_Camsaveinfo.iAck	   = BYTE2NUM(pByte[11]);
	//�ѳ��͵����Ʒ���ȥ
	if(IsTrackOK())
	{
		memcpy(camera_code,pData,sizeof(CAMERA_IDENTIFY_ID));

		CAMERAINFO* pInfo = GetCurrentCameraInfo();
		if (pInfo)
		{
			if (m_hwnd)
			{
				COPYDATASTRUCT cp;
				cp.cbData = wcslen(pInfo->deviceName);
				cp.lpData = pInfo->deviceName;
				::SendMessage(m_hwnd,WM_COPYDATA,TRACK_TYPE_CAR_NAME,(LPARAM)&cp);
			}
			if(m_funSendData)
				m_funSendData(TRACK_TYPE_CAR_NAME,(LPVOID)pInfo->deviceName,m_renderclass);
		}
		SaveTrackBackInfo();
		SetTrackSettingMode(TRACK_MODE_NORMAL,true);

		//���������һ������
		SetCameraCode(camera_code);
		//
		UpdateTrack();
		return true;
	}
	return false;
}

void Track::SetTrackSettingMode(int val,bool bNotify /*= false*/) 
{ 
	m_nTrackSettingMode = val; 
	if (bNotify)
	{
		if (m_hwnd)
		{
			COPYDATASTRUCT cp;
			cp.cbData = sizeof(m_nTrackSettingMode);
			cp.lpData = &m_nTrackSettingMode;
			::SendMessage(m_hwnd,WM_COPYDATA,TRACK_TYPE_SETTINGMODE,(LPARAM)&cp);
		}
		//�ص������������û�д���
		if (m_funSendData)
		{
			m_funSendData(TRACK_TYPE_SETTINGMODE,&m_nTrackSettingMode,m_renderclass);
		}
	}
}

#define STOP_LINE_COLOR RGB(0, 0, 0x7f)

void Track::SendTrackData(int nIndex,Co_Point* pdata,int nNum)
{
	TRACK_DATA data;
	ZeroMemory(&data,sizeof(TRACK_DATA));

	if (nIndex >=0&&nIndex < MAX_LINE_NUM-1)
	{
		data.infoHeader.ColorR = 0;
		data.infoHeader.ColorG = 0;
		data.infoHeader.ColorB = 0x7f;
		if (GetTrackSettingMode() == TRACK_MODE_SETTING&&(nIndex == MAX_LINE_NUM-2))
		{
			data.infoHeader.nIsLastTrack = ((1<<16)|nIndex);
		}
		else
		{
			data.infoHeader.nIsLastTrack = nIndex;
		}
	}
	else if (nIndex == MAX_LINE_NUM-1)
	{
		if(OldAngleIndex==0)
		{
			data.infoHeader.ColorR = 0;
			data.infoHeader.ColorG = 255;
			data.infoHeader.ColorB = 0;
		}
		else if(((MinAngle+4<0 && OldAngleIndex<MinAngle+4)) || //������һ�����Ƕ���λ
			((MaxAngle-4>0) && OldAngleIndex>MaxAngle-4))
		{
			data.infoHeader.ColorR = 240;
			data.infoHeader.ColorG = 0;
			data.infoHeader.ColorB = 0;
		}
		else
		{ 
			data.infoHeader.ColorR = 255;
			data.infoHeader.ColorG = 128;
			data.infoHeader.ColorB = 0;
		}
		data.infoHeader.nIsLastTrack = ((1<<16)|nIndex);
	}
	data.infoHeader.nPointCount = nNum;
	data.infoHeader.track_angle = OldAngleIndex;
	memcpy(&data.pointData[PTDATA_START_INDEX],pdata,sizeof(Co_Point)*nNum);
	if (m_hwnd)
	{
		COPYDATASTRUCT cp;
		cp.cbData = nNum*sizeof(Co_Point)+sizeof(TRACK_DATA_INFO);
		cp.lpData = &data;
		::SendMessage(m_hwnd,WM_COPYDATA,TRACK_TYPE_DATA,(LPARAM)&cp);
	}
	//�ص������������û�д���
	if (m_funSendData)
	{
		m_funSendData(TRACK_TYPE_DATA,&data,m_renderclass);
	}
}

int  Track::OffsetX4Correct()
{
	return MAX_OFFSET_X*m_scalex;
}

int  Track::OffsetY4Correct()
{
	return MAX_OFFSET_Y*m_scaley;
}

void Track::SetScale(float fx,float fy)
{
	m_scalex = fx;
	m_scaley = fy;
	UpdateTrack();
}

bool Track::IsTrackOK()
{
	CAMERAINFO* pInfo = GetCurrentCameraInfo();
	if (!pInfo)
		return false;
	return true;
}