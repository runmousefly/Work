#if !defined(AFX_CAMERADEFINE_H__553709A4_88E0_SDFV_87E5_C98BCB42B6A8__INCLUDED_)
#define AFX_CAMERADEFINE_H__553709A4_88E0_SDFV_87E5_C98BCB42B6A8__INCLUDED_

#define TIMER_CHECK_TRACK_CONCNECT  10
#define TIMER_CHECK_RADAR_CONNECT  11
#define TIMER_MOVE_TRACK  12
#define TIMER_INIT       13
#define TIMER_CAMERA_HIDE 14
#define SHOW_BUTTON_ID       1000
//
#define WM_UPDATE_TRACK  (WM_APP + 105)
#define WM_UPDATE_RADAR  (WM_APP + 106)
#define WM_UPDATESCREEN  (WM_APP + 107)

#define WM_CAMERA_SHOW     (WM_APP+108)
#define WM_CAMERA_HIDE     (WM_APP+109)
#define WM_DEALWITH_8811   (WM_APP+113)
#define WM_SHOW   (WM_APP + 101)
#define WM_HIDE   (WM_APP + 102)
#define  WM_GOTO_DESKTOP (WM_APP+2870)

#define BUTTON_SETTING    2000

#define BUTTON_UP       2002
#define BUTTON_DOWN     2004
#define BUTTON_LEFT     2001
#define BUTTON_RIGHT    2003
#define BUTTON_POSADJUST_CONFIRM 2005
#define BUTTON_POSADJUST_CANCEL  2006
#define BUTTON_REVERSE   2007
#define BUTTON_MODESEL   2009

#define BUTTON_OVERALLVIEW_MOD    2010
#define BUTTON_OVERALLVIEW_MENU   2011

#define TRANSPARENT_COLOR  RGB(255,255,255)

#define EnableSendExitMsg    0
#define DisableSendExitMsg    1

#define UserResume             1
#define BackingCar             0


enum SETTINGOPTIION
{
	NO_OPTION,
	POS_ADJUST,
	MIRROR_SETTING,
	PARA_INPUT,
};


typedef struct IndicatorInfo
{
	int x;
	int y;
	int width;
	int height;
}INDICATORINFO;

typedef struct CameraInformation
{
	//CString cameratype;
	TCHAR camcode[32];
	int angle;
	int offset;
	TCHAR deviceName[32];

	CameraInformation()
	{
		memset(&camcode, 0, sizeof(camcode));	
		angle = 0;
		offset = 0;
		memset(&deviceName, 0, sizeof(deviceName));	
	};
}CAMERAINFO;

#define printf


#define STRLEFT  300
#define STRTOP   330
#define STRRIGHT 550
#define STRBOTTOM  410

static RECT StrRect={STRLEFT,STRTOP,STRRIGHT,STRBOTTOM};


#define KEY_UP    0
#define KEY_DOWN    1
#define MOVETIME    10


struct Track_Back{
	BYTE iCM_Type; 
	BYTE iLen_Type;        //��Ƭ����
	BYTE bZE_Angle;
	int iTrack_x, iTrack_y;
	BYTE iAck;
};

#define  D107_STORGE_TrackPoint_PATH  L"C:\\TrackPoint.bin"
#define  D107_TrackPointIndex_PATH    L"C:\\TrackPointIndex.cfg"
#define ISVALIDHANDLE(h) ((h) != INVALID_HANDLE_VALUE&&(h) !=NULL)

#endif // !defined(AFX_CAMERADEFINE_H__553709A4_88E0_SDFV_87E5_C98BCB42B6A8__INCLUDED_)