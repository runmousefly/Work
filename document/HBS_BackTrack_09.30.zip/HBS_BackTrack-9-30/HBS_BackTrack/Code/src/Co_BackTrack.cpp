// Co_BackTrack.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "Co_BackTrack.h"
#include "CamTrack.h"

#ifdef _MANAGED
#pragma managed(push, off)
#endif
static	 Track   m_track;
#ifndef _WIN32_WCE
BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch(ul_reason_for_call)
	{
	case DLL_PROCESS_DETACH:
	case DLL_THREAD_DETACH:
		{
			m_track.UnInit();
		}
		break;
	}
    return TRUE;
}
#else
BOOL APIENTRY DllMain( HANDLE hModule, 
					  DWORD  ul_reason_for_call, 
					  LPVOID lpReserved
					  )
{
	switch(ul_reason_for_call)
	{
	case DLL_PROCESS_DETACH:
	case DLL_THREAD_DETACH:
		{
			fwprintf(stderr,L"_____lxl______ul_reason_for_call %d\n");
			//m_track.UnInit();
		}
		break;
	}
	return TRUE;
}
#endif
//��ʼ��
int   CoInitDataPath(LPCTSTR lpstrindex,LPCTSTR lpstrData)
{
	m_track.InitFilePaths(lpstrindex,lpstrData);
	return HBS_ERROR_OK;
}
int   CoInitTrack(HWND flag)
{
	m_track.InitTrack(flag);
	return HBS_ERROR_OK;
}

int   CoInitTrack2(FunTrackDataBack pCallBack,LPVOID lpdata)
{
	m_track.InitTrack(pCallBack,lpdata);
	return HBS_ERROR_OK;
}
//����ʼ��
int   CoUnInitTrack()
{
	m_track.UnInit();
	return HBS_ERROR_OK;
}
//////////////////////////////////////////////////////////////////////////
//����
//////////////////////////////////////////////////////////////////////////
//���õ�ǰ��ģʽ.
int   CoSetTrackMode(int nMode)
{
	m_track.SetTrackSettingMode(nMode);
	return HBS_ERROR_OK;
}

//��ȡ��ǰ��ģʽ
int   CoGetTrackMode()
{
	return  m_track.GetTrackSettingMode();
}

//���복�ʹ���
int   CoSetCameraCode(int nTrackCode)
{
	if(m_track.SetTrackCode(nTrackCode))
	{
		return HBS_ERROR_OK;
	}
	return HBS_ERROR_WRONG_PARAM;
}
//��ȡ���õĳ��ʹ���
int   CoGetCameraCode(OUT int* pCode)
{
	if (pCode)
	{
		*pCode = m_track.GetTrackCode();
		return HBS_ERROR_OK;
	}
	return HBS_ERROR_WRONG_PARAM;
}

//���ù켣��ƫ��.
int   CoOffsetTrack(int nX,int nY)
{
	m_track.OffsetTrack(nX,nY);
	return HBS_ERROR_OK;
}

int   CoSaveTrackSetting()
{
	m_track.SaveTrackBackInfo();
	return HBS_ERROR_OK;
}
//���뾵ͷУ������
int   CoSetCameraID(CAMERA_IDENTIFY_ID *pData)
{
	if (pData)
	{
		if(m_track.SetCameraID(pData))
		{
			return HBS_ERROR_OK;
		}
	}
	return HBS_ERROR_WRONG_PARAM;
}

//��ȡ��ͷУ������
int   CoGetCameraID(CAMERA_IDENTIFY_ID *pData)
{
	if (pData)
	{
		memcpy(pData,m_track.camera_code,sizeof(CAMERA_IDENTIFY_ID));
		return HBS_ERROR_OK;
	}
	return HBS_ERROR_WRONG_PARAM;
}

int   CoSetAngle(int nAngle)
{
	if(m_track.SetCurrentAngle(nAngle))
		return HBS_ERROR_OK;
	return HBS_ERROR_WRONG_PARAM;
}

int   CoSetCanAngle(BYTE* pdata,int nCnt)
{
	if(m_track.SetCurrentAngle(pdata,nCnt))
		return HBS_ERROR_OK;
	return HBS_ERROR_WRONG_PARAM;
}

int  CoSetScale(float nx,float ny){
	m_track.SetScale(nx,ny);
	return HBS_ERROR_OK;
}
//////////////////////////////////////////////////////////////////////////
//��������
int   CoTrackInvoke(int nmessage,LPVOID pdata)
{
	if (nmessage == 0)
	{
		m_track.SetCurrentAngle((UCHAR*)pdata,4);
	}
	return HBS_ERROR_NOHANDLE;
}


#ifdef _MANAGED
#pragma managed(pop)
#endif