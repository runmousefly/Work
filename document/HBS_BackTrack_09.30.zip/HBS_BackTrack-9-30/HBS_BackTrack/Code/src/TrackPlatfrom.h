#ifndef __TRACKPLATFROM_H__
#define __TRACKPLATFROM_H__

//
#if defined(_WIN32)||defined(_WIN32_WCE)
#include <windows.h>
#else
//to 
#ifndef IN
#define IN	
#define OUT 
#endif

#endif

#endif  // end of __TRACKPLATFROM_H__