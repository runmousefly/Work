// BackTrackSettingDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BackTrackSetting.h"
#include "BackTrackSettingDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define  __IS_CAN_ANGLEDATA_PARSE_BY_APP__     1


// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���
#ifdef _WIN32_WCE
CCo_BusProtocoldllLoader<Co_BusHelper,USER_TYPE_BUSHELPER>   m_busloader;
#endif

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CBackTrackSettingDlg �Ի���
CBackTrackSettingDlg::CBackTrackSettingDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBackTrackSettingDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_nangle= 0;
#ifdef _WIN32_WCE
	m_bushelper  = NULL;
#endif
}

void CBackTrackSettingDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_editInput);
	DDX_Control(pDX, IDC_STATICNAME, m_staticname);
	DDX_Control(pDX, IDC_STATICID, m_staticid);
	DDX_Control(pDX, IDC_BTN_LEFT, m_btnLeft);
	DDX_Control(pDX, IDC_BTN_RIGHT, m_btnRight);
	DDX_Control(pDX, IDC_BTN_UP, m_btnUp);
	DDX_Control(pDX, IDC_BTN_DOWN, m_btnDown);
	DDX_Control(pDX, IDC_CHECK_UPDATE, m_checkbtn);
}

BEGIN_MESSAGE_MAP(CBackTrackSettingDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, &CBackTrackSettingDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BTNINPUT, &CBackTrackSettingDlg::OnBnClickedBtninput)
	ON_BN_CLICKED(IDC_BTNADD, &CBackTrackSettingDlg::OnBnClickedBtnadd)
	ON_BN_CLICKED(IDC_BTNDEL, &CBackTrackSettingDlg::OnBnClickedBtndel)
	ON_BN_CLICKED(IDC_BTN_LEFT, &CBackTrackSettingDlg::OnBnClickedBtnLeft)
	ON_BN_CLICKED(IDC_BTN_UP, &CBackTrackSettingDlg::OnBnClickedBtnUp)
	ON_BN_CLICKED(IDC_BTN_RIGHT, &CBackTrackSettingDlg::OnBnClickedBtnRight)
	ON_BN_CLICKED(IDC_BTN_DOWN, &CBackTrackSettingDlg::OnBnClickedBtnDown)
	ON_BN_CLICKED(IDC_BTNSAVE, &CBackTrackSettingDlg::OnBnClickedBtnsave)
	ON_EN_SETFOCUS(IDC_EDIT1, &CBackTrackSettingDlg::OnEnSetfocusEdit1)
END_MESSAGE_MAP()


// CBackTrackSettingDlg ��Ϣ��������

BOOL CBackTrackSettingDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��
#ifdef _WIN32_WCE
	if(m_busloader.Load(BUSPROTOCOL_PATH))
	{
		m_bushelper = m_busloader.getclass();
		m_bushelper->registerwin(GetSafeHwnd(),MAKE_PROTOCOL_ID(0x03,0x0f,0,0));
		m_bushelper->registerwin(GetSafeHwnd(),MAKE_PROTOCOL_ID(MCU2APP_ADD_GID,MCU2APP_TRACK_DATA_RET,0,0));
	}
#endif
	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	if(m_BackTrackApi.Init(CO_BACKTRACK_DLL_PATH))
	{
		m_BackTrackApi.InitTrackDataPath(CO_TrackPointIndex_PATH,CO_STORGE_TrackPoint_PATH);
		m_BackTrackApi.InitTrack(TrackDataCallBack,(LPVOID)this);
		//����û�����õĻ�Ҫ������Ӧ������
		//����id����������mcu���м���ģ�Ҫ��Co_BusProtocol�л�ȡ��Ӧ��ֵ���룬��������ֻ��ʾ����ô���á�
		CAMERA_IDENTIFY_ID cameraid ={'2','0','7','2','0','0','5','0','0','5','0','7'};
		m_BackTrackApi.SetCameraID(&cameraid);
		m_editInput.SetWindowText(L"20720");
	}
	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CBackTrackSettingDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CBackTrackSettingDlg::OnPaint()
{
	CDialog::OnPaint();
	UpdateLines();
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù����ʾ��
//
HCURSOR CBackTrackSettingDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void  CBackTrackSettingDlg::TrackDataCallBack(int ntype,LPVOID lpdata,LPVOID lpclass)
{
	CBackTrackSettingDlg* pDlg = (CBackTrackSettingDlg*)lpclass;
	if (pDlg)
	{
		pDlg->DataCalllBack(ntype,lpdata);
	}
}

void CBackTrackSettingDlg::DataCalllBack(int ntype,LPVOID lpdata)
{
	switch(ntype)
	{
	case TRACK_TYPE_DATA:
		{
			TRACK_DATA* trackdata = (TRACK_DATA*)lpdata; 
			int nSize  = trackdata->infoHeader.nPointCount+PTDATA_START_INDEX;
			int nIndex = LOWORD(trackdata->infoHeader.nIsLastTrack);
			if (nIndex >=0&&nIndex < MAX_LINE_NUM)
			{
				ZeroMemory((LPVOID)&m_trackdatas[nIndex],sizeof(m_trackdatas[nIndex]));
				memcpy((LPVOID)&m_trackdatas[nIndex],lpdata,sizeof(Co_Point)*nSize);
			}
			if (HIWORD(trackdata->infoHeader.nIsLastTrack)) //����һ����
			{
				Invalidate();
			}
		}
		break;
	case TRACK_TYPE_CAR_NAME:
		{
			m_staticname.SetWindowText((LPCTSTR)lpdata);
		}
		break;
	case TRACK_TYPE_ID_DATA:
		{
			CAMERA_IDENTIFY_ID id ;
			memcpy(id.bIDData,lpdata,sizeof(id));
			TCHAR szbuf[32]={0};
			for (int nSize = 0;nSize < TRACK_ID_NUM;nSize++)
			{
				szbuf[nSize] =L'0'+(id.bIDData[nSize]-'0');
			}
			szbuf[TRACK_ID_NUM] =0;
			m_staticid.SetWindowText(szbuf);
		}
		break;
	case TRACK_TYPE_SETTINGMODE:
		{
			int nMode =(int)(*(int*)lpdata);
			switch(nMode)
			{
			case TRACK_MODE_NORMAL:
				{
					m_btnDown.ShowWindow(SW_HIDE);
					m_btnUp.ShowWindow(SW_HIDE);
					m_btnLeft.ShowWindow(SW_HIDE);
					m_btnRight.ShowWindow(SW_HIDE);
				}
				break;
			case TRACK_MODE_PARAM_INPUT:
				{
					m_staticname.ShowWindow(SW_SHOW);
					m_staticname.SetWindowText(L"�����뾵ͷID!");
				}
				break;
			case TRACK_MODE_SETTING:
				{
					m_staticid.ShowWindow(SW_SHOW);
					m_staticname.ShowWindow(SW_SHOW);

					m_btnDown.ShowWindow(SW_SHOW);
					m_btnUp.ShowWindow(SW_SHOW);
					m_btnLeft.ShowWindow(SW_SHOW);
					m_btnRight.ShowWindow(SW_SHOW);
				}
				break;
			case TRACK_MODE_NOTHING:
				{
					m_staticid.ShowWindow(SW_HIDE);
					m_staticname.ShowWindow(SW_HIDE);
				}
				break;
			}
		}
		break;
	default:
		break;
	}
}


void CBackTrackSettingDlg::OnBnClickedBtninput()
{
	// TODO: Add your control notification handler code here
	CString str;
	m_editInput.GetWindowText(str);
	if (str.CompareNoCase(L"7253")==0)
	{
		m_BackTrackApi.SetTrackMode(TRACK_MODE_PARAM_INPUT);
		m_staticname.SetWindowText(L"�����뾵ͷID!");
	}
	else 
	{
		if (str.GetLength() == 5)
		{
			m_BackTrackApi.SetCameraCode(_wtoi(str));
		}	
		else if(str.GetLength() == TRACK_ID_NUM)
		{
			CAMERA_IDENTIFY_ID id={0};
			LPCTSTR lpstr = (LPCTSTR)str;
			for (int nSize = str.GetLength()-1; nSize >=0;nSize--)
			{
				id.bIDData[nSize] = (lpstr[nSize]-L'0')+'0';
			}
			m_BackTrackApi.SetCameraID(&id);
		}
	}
}
// ����CANԭʼ�Ƕ����ݵĽӿ� [5/5/2014 lixielong]
static BYTE wheeldata[9][8]={
	{0x88,0x30,0x00,0x00,0x80,0x00,0xF9,0x47},
	{0x21,0x1C,0x7B,0x08,0x80,0x80,0x8F,0xBF},
	{0x1E,0x10,0xD7,0x0D,0x80,0x00,0x2E,0xED},
	{0xA5,0x04,0x25,0x07,0x80,0xC0,0x4C,0x6A},
	{0x00,0x00,0x72,0x00,0x80,0x20,0x92,0x6D},
	{0xA9,0x88,0x49,0x0E,0x80,0xC0,0x6C,0xB7},
	{0x95,0x8F,0x6E,0x15,0x80,0x40,0x77,0x18},
	{0x53,0xA0,0x6E,0x15,0x80,0xA0,0x17,0xE9},
	{0x71,0xB0,0x00,0x00,0x80,0x40,0xE4,0x9E},
};
static int  g_nIndex = 4;

void CBackTrackSettingDlg::OnBnClickedBtnadd()
{
	// TODO: Add your control notification handler code here
#if !__IS_CAN_ANGLEDATA_PARSE_BY_APP__
	m_nangle++;
	if (m_nangle >40)
	{
		m_nangle = 40;
	}
	m_BackTrackApi.SetAngle(m_nangle);
#else
	g_nIndex ++;
	if (g_nIndex >=9)
	{
		g_nIndex = 0;
	}
	m_BackTrackApi.SetCanAngle(wheeldata[g_nIndex],8);
#endif
}

void CBackTrackSettingDlg::OnBnClickedBtndel()
{
	// TODO: Add your control notification handler code here
#if !__IS_CAN_ANGLEDATA_PARSE_BY_APP__
	m_nangle--;
	if (m_nangle < -40)
	{
		m_nangle = -40;
	}
	m_BackTrackApi.SetAngle(m_nangle);
#else
	g_nIndex--;
	if (g_nIndex <0)
	{
		g_nIndex = 0;
	}
	m_BackTrackApi.SetCanAngle(wheeldata[g_nIndex],2);
#endif
}

void CBackTrackSettingDlg::OnBnClickedOk()
{
#ifdef _WIN32_WCE
	BYTE data[]={ APP2MCU_ADD_GID,APP2MCU_TRACK_DATA_REQ};
	m_bushelper->SendData2Stm32(data,2);
#endif
}

void CBackTrackSettingDlg::UpdateLines()
{
	HDC hdc = ::GetDC(GetSafeHwnd());
	DrawLines(hdc);
	::ReleaseDC(GetSafeHwnd(),hdc);
}

void CBackTrackSettingDlg::DrawLines(HDC hdc)
{
	if (hdc)
	{
		int nPos = 0;
		for (int nSize = 0; nSize < MAX_LINE_NUM; nSize++)
		{
			TRACK_DATA_INFO* info = &m_trackdatas[nSize].infoHeader;
			Co_Point* pPoints = m_trackdatas[nSize].pointData;
			if (info->nPointCount >0)
			{
				HPEN hPen=(HPEN)::SelectObject(hdc,::CreatePen(0,2,RGB(info->ColorR,info->ColorG,info->ColorB)));
				int nx = 0;
				int ny = 0;
				for (int nindex = 0; nindex < info->nPointCount;nindex++)
				{
					if (nindex == 0)
					{
						nPos = PTDATA_START_INDEX;
						nx = pPoints[nPos].x;
						ny = pPoints[nPos].y;
						MoveToEx(hdc,nx,ny,NULL);
					}
					else{
						nx +=pPoints[nPos].x;
						ny +=pPoints[nPos].y;
						LineTo(hdc,nx,ny);
					}
					nPos++;
				}
				::DeleteObject(::SelectObject(hdc, hPen));
			}
			if (HIWORD(info->nIsLastTrack) != 0)
			{
				break; //���һ���߽�������
			}
		}
	}
}
void CBackTrackSettingDlg::OnBnClickedBtnLeft()
{
	// TODO: Add your control notification handler code here
	m_BackTrackApi.OffsetTrack(-1,0);
}

void CBackTrackSettingDlg::OnBnClickedBtnUp()
{
	// TODO: Add your control notification handler code here
	m_BackTrackApi.OffsetTrack(0,-1);
}

void CBackTrackSettingDlg::OnBnClickedBtnRight()
{
	// TODO: Add your control notification handler code here
	m_BackTrackApi.OffsetTrack(1,0);
}

void CBackTrackSettingDlg::OnBnClickedBtnDown()
{
	// TODO: Add your control notification handler code here
	m_BackTrackApi.OffsetTrack(0,1);

}

void CBackTrackSettingDlg::OnBnClickedBtnsave()
{
	// TODO: Add your control notification handler code here
	m_BackTrackApi.SaveTrackSetting();//�����¼���һ��id
#ifdef _WIN32_WCE
	CAMERA_IDENTIFY_ID id;
	if(m_BackTrackApi.GetCameraID(&id)== HBS_ERROR_OK)
	{
		//����Co_busProtocol.dll��ߵ�Co_BusHelper��SendData2Stm32�������������·�
		BYTE data[12+2]={APP2MCU_ADD_GID,APP2MCU_TRACK_DATA_SAVE};
		memcpy(&data[2],id.bIDData,12);
		m_bushelper->SendData2Stm32(data,12+2);
	}
#endif

}

void CBackTrackSettingDlg::OnEnSetfocusEdit1()
{
	// TODO: Add your control notification handler code here
#ifdef _WIN32_WCE
	SipShowIM(SIPF_ON);
#endif
}


LRESULT CBackTrackSettingDlg::WindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: �ڴ�����ר�ô����/����û���
	if (message == WM_COPYDATA)
	{
		COPYDATASTRUCT* cp = (COPYDATASTRUCT*)lParam;
		BYTE* pdata = (BYTE*)cp->lpData;
		if (pdata[0] == 0x03&&pdata[1]==0xF)
		{
			if (m_checkbtn.GetCheck())
			{	
#if __IS_CAN_ANGLEDATA_PARSE_BY_APP__//�������APP�������Ƕ����ݵĻ�,ֱ�Ӱ����ݴ���ȥ
				m_BackTrackApi.SetCanAngle(pdata+2,cp->cbData-2); 
#else
				m_nangle = (pdata[2]);
				m_BackTrackApi.SetAngle(m_nangle);
#endif
			}
		}
#ifdef _WIN32_WCE
		else if (pdata[0] == MCU2APP_ADD_GID&&pdata[1] == MCU2APP_TRACK_DATA_RET)
		{
			CAMERA_IDENTIFY_ID id;
			memcpy(id.bIDData,pdata+2,12);
			m_BackTrackApi.SetCameraID(&id);
		}
#endif
	}
	return CDialog::WindowProc(message, wParam, lParam);
}
