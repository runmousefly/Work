#ifndef __CO_CAR_PROTOCOLDEF_H__
#define __CO_CAR_PROTOCOLDEF_H__

#include <Windows.h>
#ifndef SAFE_DELETE
#define SAFE_DELETE(x) if((x)) { delete	(x); (x) = NULL;}			
#endif
#ifdef CO_BUSPROTOCOL_EXPORTS
#define HBS_EXT_CLASS __declspec(dllexport)
#else 
#define HBS_EXT_CLASS __declspec(dllimport)
#endif

/*Error code*/
enum HBS_RESULT{
	HBS_ERROR_OK = 0,		/*���ݴ���OK*/
	HBS_ERROR_NOHANDLE,		/*����û�д���*/
	HBS_ERROR_NOINIT,		/*����û�г�ʼ��*/
	HBS_ERROR_NOMOREMEMORY, /*�ڴ治��*/
	HBS_ERROR_TIMEOUT,		/*��ʱ*/
	HBS_ERROR_NOWINDOWS,	/*û�д���*/
	HBS_ERROR_WRONG_PARAM,  /*��������*/
	HBS_ERROR_UNKNOW = HBS_ERROR_OK+100,   /*δ֪����*/
};
/*user type*/
typedef  UCHAR muchar;
typedef  muchar*  pmuchar;
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
/*
* ע��������ݵĴ���
* ע����֮��,CO_carProtocol.dll�ͻ��򴰿ڷ�����Ӧ������
*/
#define		WM_MSG_CAR_APP_2_PROTOCOL  WM_USER+1234
//wparam:   ����HWND
//lParam:   CO_IDENTIFY_ID  //ֻʹ��ǰ�ߵ�groupid��subid
//////////////////////////////////////////////////////////////////////////
//��������������
#define MAX_FRAME_SIZE 85
#define MAX_RECORD_ITEM 0xff
//CO_IDENTIFY_ID
#define  CO_IDENTIFY_ID	int
/*
*  ����CO_IDENTIFY_ID�ĺ�
*  ��ʽ˵��:g:groupid 
*			s:subid ���ڴ������ݵĽ��ղ���ֻ����������ֵ�Ϳ����ˡ�
*			e:��չ��id(�󲿷�������ͨ��data0��ϸ��Э������ݵ�)
*			i:��Ӧ�������ڹ����ڴ���������λ��,������ߵ�λ���Ǵ�1��ʼ��.
*/
#define  MAKE_PROTOCOL_ID(g,s,e,i) (((g)<<24)|((s)<<16)|((e)<<8)|(i))
#define  GET_INDEX_FROM_ID(id) ((id)&0xff)
//���ڵ�Э���
//ע:�����µ�Э���������ĺ꿪ʼ����
#define CarDisplaysStrASII  MAKE_PROTOCOL_ID(5,1,0,1)   //������ߵ�λ���Ǵ�1��ʼ��
#define CarDisplaysStrUnicode MAKE_PROTOCOL_ID(5,2,0,2)
#define CarDisplaysStrUtf8  MAKE_PROTOCOL_ID(5,3,0,3)
#define AirBaseInfo			MAKE_PROTOCOL_ID(6,1,0,4)
#define AirDisplyInfo		MAKE_PROTOCOL_ID(6,2,0,5)
#define FMBaseInfo			MAKE_PROTOCOL_ID(7,1,0,6)
#define RdsInfo				MAKE_PROTOCOL_ID(7,2,0,7)
#define CDBaseInfo			MAKE_PROTOCOL_ID(8,1,0,8)
#define CDTonjiInfo			MAKE_PROTOCOL_ID(8,2,0,9) //ͳ����Ϣ
#define CDDiskandPlaymode	MAKE_PROTOCOL_ID(8,3,0,10)
#define IPodUSBdevice		MAKE_PROTOCOL_ID(9,1,0,11)
#define IPodUSBPlayindex	MAKE_PROTOCOL_ID(9,2,0,12)
#define IPodUSBPlayTimeandStatue MAKE_PROTOCOL_ID(9,3,0,13)
#define IPodUSBFileName		MAKE_PROTOCOL_ID(9,4,0,14)
#define IPodUSBid3FileName	MAKE_PROTOCOL_ID(9,5,0,15)
#define IPodUSBid3Artist	MAKE_PROTOCOL_ID(9,6,0,16)
#define IPodUSBid3Alumb		MAKE_PROTOCOL_ID(9,7,0,17)
#define IPodUSBid3Null		MAKE_PROTOCOL_ID(9,8,0,18)
#define IPodUSBDeviceExit	MAKE_PROTOCOL_ID(9,9,0,19)
#define IPodUSBFolderinfo	MAKE_PROTOCOL_ID(9,0xa,0,20)
#define IPodUSBFolderpath	MAKE_PROTOCOL_ID(9,0xb,0,21)
#define IPodUSBFolderlist1	MAKE_PROTOCOL_ID(9,0xc,1,22)
#define IPodUSBFolderlist2	MAKE_PROTOCOL_ID(9,0xc,2,23)
#define IPodUSBFolderlist3	MAKE_PROTOCOL_ID(9,0xc,3,24)
#define IPodUSBFolderlist4	MAKE_PROTOCOL_ID(9,0xc,4,25)
#define IPodUSBFolderlist5	MAKE_PROTOCOL_ID(9,0xc,5,26)
#define IPodUSBFolderlist6	MAKE_PROTOCOL_ID(9,0xc,6,27)
#define IPodUSBFolderlist7	MAKE_PROTOCOL_ID(9,0xc,7,28)
#define IPodUSBFolderlist8	MAKE_PROTOCOL_ID(9,0xc,8,29)
#define IPodUSBFolderlist9	MAKE_PROTOCOL_ID(9,0xc,9,30)
#define IPodUSBFolderlista	MAKE_PROTOCOL_ID(9,0xc,0xa,31)
#define IPodUSBFolderlistb	MAKE_PROTOCOL_ID(9,0xc,0xb,32)
#define IPodUSBFolderlistc	MAKE_PROTOCOL_ID(9,0xc,0xc,33)
#define IPodUSBFolderlistd	MAKE_PROTOCOL_ID(9,0xc,0xd,34)
#define IPodUSBFolderliste	MAKE_PROTOCOL_ID(9,0xc,0xe,35)
#define IPodUSBFolderlistf	MAKE_PROTOCOL_ID(9,0xc,0xf,36)
#define RaderBackDistance	MAKE_PROTOCOL_ID(0xa,1,0,37)
#define RaderBackNoDistance	MAKE_PROTOCOL_ID(0xa,2,0,38)
#define RaderFrontDistance	MAKE_PROTOCOL_ID(0xa,3,0,39)
#define RaderFrontNoDistance MAKE_PROTOCOL_ID(0xa,4,0,40)
#define BtStatue			 MAKE_PROTOCOL_ID(0xb,1,0,41)
#define BtDisplay1			MAKE_PROTOCOL_ID(0xb,2,1,42)
#define BtDisplay2			MAKE_PROTOCOL_ID(0xb,2,2,43)
#define BtDisplay3			MAKE_PROTOCOL_ID(0xb,2,3,44)
#define BtDisplay4			MAKE_PROTOCOL_ID(0xb,2,4,45)
#define BtDisplay5			MAKE_PROTOCOL_ID(0xb,2,5,46)
#define BtDisplay6			MAKE_PROTOCOL_ID(0xb,2,6,47)
#define BtDisplay7			MAKE_PROTOCOL_ID(0xb,2,7,48)
#define BtDisplay8			MAKE_PROTOCOL_ID(0xb,2,8,49)
#define BtDisplay9			MAKE_PROTOCOL_ID(0xb,2,9,50)
#define BtDisplaya			MAKE_PROTOCOL_ID(0xb,2,0xa,51)
#define BtDisplayb			MAKE_PROTOCOL_ID(0xb,2,0xb,52)
#define BtDisplayc			MAKE_PROTOCOL_ID(0xb,2,0xc,53)
#define BtDisplayd			MAKE_PROTOCOL_ID(0xb,2,0xd,54)
#define BtDisplaye			MAKE_PROTOCOL_ID(0xb,2,0xe,55)
#define BtDisplayf			MAKE_PROTOCOL_ID(0xb,2,0xf,56)
#define BtMusicFunction		MAKE_PROTOCOL_ID(0xb,3,0,57)
#define CarInfoCarRun1		MAKE_PROTOCOL_ID(0xc,1,1,58)
#define CarInfoCarRun2		MAKE_PROTOCOL_ID(0xc,1,2,59)
#define CarInfoCarRun3		MAKE_PROTOCOL_ID(0xc,1,3,60)
#define CarInfoCarRun4		MAKE_PROTOCOL_ID(0xc,1,4,61)
#define CarInfoCarRun5		MAKE_PROTOCOL_ID(0xc,1,5,62)
#define CarInfoCarRun6		MAKE_PROTOCOL_ID(0xc,1,6,63)
#define CarInfoCarRun7		MAKE_PROTOCOL_ID(0xc,1,7,64)
#define CarInfoCarRun8		MAKE_PROTOCOL_ID(0xc,1,8,65)
#define CarInfoCarRun9		MAKE_PROTOCOL_ID(0xc,1,9,66)
#define CarInfoCarRuna		MAKE_PROTOCOL_ID(0xc,1,0xa,67)
#define CarInfoCarRunb		MAKE_PROTOCOL_ID(0xc,1,0xb,68)
#define CarInfoCarRunc		MAKE_PROTOCOL_ID(0xc,1,0xc,69)
#define CarInfoCarRund		MAKE_PROTOCOL_ID(0xc,1,0xd,70)
#define CarInfoCarRune		MAKE_PROTOCOL_ID(0xc,1,0xe,71)
#define CarInfoCarRunf		MAKE_PROTOCOL_ID(0xc,1,0xf,72)
#define CarInfoCarRun10		MAKE_PROTOCOL_ID(0xc,1,0x10,73)
#define CarInfoCarRun11		MAKE_PROTOCOL_ID(0xc,1,0x11,74)
#define CarInfoWarning		MAKE_PROTOCOL_ID(0xc,2,0,75)
#define CarInfoAutodiagnose MAKE_PROTOCOL_ID(0xc,3,0,76)
#define CarInfo0C04			MAKE_PROTOCOL_ID(0xc,4,0,77)
#define CarInfoCarDoor		MAKE_PROTOCOL_ID(0xc,5,0,78)
#define CarInfoPassoil		MAKE_PROTOCOL_ID(0xc,6,0,79)
#define CarInfoMinuteoil	MAKE_PROTOCOL_ID(0xc,7,0,80)
#define CarInfooilandpower	MAKE_PROTOCOL_ID(0xc,8,0,81)
#define CarInfoDoorControl	MAKE_PROTOCOL_ID(0xc,9,0,82)
#define CarInfoSafeSet		MAKE_PROTOCOL_ID(0xc,0xa,0,83)
#define CarInfoComfortableSet MAKE_PROTOCOL_ID(0xc,0xb,0,84)
#define CarInfoSportSet		MAKE_PROTOCOL_ID(0xc,0xc,0,85)
#define CarInfoAirControl	MAKE_PROTOCOL_ID(0xc,0xd,0,86)
#define CarInfoK314			MAKE_PROTOCOL_ID(0xc,0xe,0,87)
#define CarInfoSpeedSet		MAKE_PROTOCOL_ID(0xc,0xf,0,88)
#define CarInfoSpeedNotify	MAKE_PROTOCOL_ID(0xc,0x10,0,89)
#define CarInfoCarParamSet  MAKE_PROTOCOL_ID(0xc,0x11,0,90)
#define CarInfoScreenset	MAKE_PROTOCOL_ID(0xc,0x12,0,91)
#define CarInfonodevice		MAKE_PROTOCOL_ID(0xc,0x13,0,92)
#define CarInfoSafeSet1		MAKE_PROTOCOL_ID(0xc,0x14,1,93)
#define CarInfoSafeSet2		MAKE_PROTOCOL_ID(0xc,0x14,2,94)
#define CarInfoSafeSet3		MAKE_PROTOCOL_ID(0xc,0x14,3,95)
#define CarInfoSafeSet4		MAKE_PROTOCOL_ID(0xc,0x14,4,96)
#define CarInfoSafeSet5		MAKE_PROTOCOL_ID(0xc,0x14,5,97)
#define CarInfoSafeSet6		MAKE_PROTOCOL_ID(0xc,0x14,6,98)
#define CarInfoSafeSet7		MAKE_PROTOCOL_ID(0xc,0x14,7,99)
#define CarInfoSafeSet8		MAKE_PROTOCOL_ID(0xc,0x14,8,100)
#define CarInfoSafeSet9		MAKE_PROTOCOL_ID(0xc,0x14,9,101)
#define CarClockDisplay     MAKE_PROTOCOL_ID(0xd,0x1,0,102)
#define AMPMuteandVol		MAKE_PROTOCOL_ID(0xe,0x1,0,103)
#define AMPValueStatue		MAKE_PROTOCOL_ID(0xe,0x2,0,104)
#define BuickCarType		MAKE_PROTOCOL_ID(0xf,0x1,0,105)
#define BuickOnStarDialNumSet	MAKE_PROTOCOL_ID(0xf,0x2,0,106)
#define BuickOnStarDialNameSet  MAKE_PROTOCOL_ID(0xf,0x2,0,107)
#define BuickOnStarServiceSet	MAKE_PROTOCOL_ID(0xf,0x2,0,108)
#define BuickOnStarhelp			MAKE_PROTOCOL_ID(0xf,0x2,0,109)
#define BuickOnStarCallComingNum  MAKE_PROTOCOL_ID(0xf,0x2,0,110)
#define BuickOnStarCallComingName MAKE_PROTOCOL_ID(0xf,0x2,0,111)
#define BuickOnStarConnect		MAKE_PROTOCOL_ID(0xf,0x2,0,112)
#define BuickOnStarCalling		MAKE_PROTOCOL_ID(0xf,0x2,0,113)
#define SyncSetting1			MAKE_PROTOCOL_ID(0x11,0x1,1,114)
#define SyncSetting2			MAKE_PROTOCOL_ID(0x11,0x1,2,115)
#define SyncSetting3			MAKE_PROTOCOL_ID(0x11,0x1,3,116)
#define SyncSetting4			MAKE_PROTOCOL_ID(0x11,0x1,4,117)
#define SyncSetting5			MAKE_PROTOCOL_ID(0x11,0x1,5,118)
#define SyncSetting6			MAKE_PROTOCOL_ID(0x11,0x1,6,119)
#define SyncSetting7			MAKE_PROTOCOL_ID(0x11,0x1,7,120)
#define SyncSetting8			MAKE_PROTOCOL_ID(0x11,0x1,8,121)
#define SyncSetting9			MAKE_PROTOCOL_ID(0x11,0x1,9,122)
#define SyncSetting10			MAKE_PROTOCOL_ID(0x11,0x1,10,123)
#define SyncSetting11			MAKE_PROTOCOL_ID(0x11,0x1,11,124)
#define SyncSetting12			MAKE_PROTOCOL_ID(0x11,0x1,12,125)
#define SyncSetting13			MAKE_PROTOCOL_ID(0x11,0x1,13,126)
#define SyncSetting14			MAKE_PROTOCOL_ID(0x11,0x1,14,127)
#define SyncSetting15			MAKE_PROTOCOL_ID(0x11,0x1,15,128)
#define SyncSetting16			MAKE_PROTOCOL_ID(0x11,0x1,16,129)
#define SyncSetting17			MAKE_PROTOCOL_ID(0x11,0x1,17,130)
#define SyncSetting18			MAKE_PROTOCOL_ID(0x11,0x1,18,131)
#define SyncSetting19			MAKE_PROTOCOL_ID(0x11,0x1,19,132)
#define SyncSetting20			MAKE_PROTOCOL_ID(0x11,0x1,20,133)
#define SyncSetting21			MAKE_PROTOCOL_ID(0x11,0x1,21,134)
#define SyncIconStatue			MAKE_PROTOCOL_ID(0x11,0x2,0,135)	//V1.0�汾�����ݵ�����
#define CAR_HANDSHARE_DATA      MAKE_PROTOCOL_ID(0x1,0x1,0,136)  //0x1,0x2û��Ҫ��
#define CAR_HANDSHARE_MCU_VER   MAKE_PROTOCOL_ID(0x1,0x3,0,137)
#define CAR_STATUE_ACC			MAKE_PROTOCOL_ID(0x3,0x1,0,138)
#define CAR_STATUE_REVERSE		MAKE_PROTOCOL_ID(0x3,0x2,0,139)
#define CAR_STATUE_BREAK		MAKE_PROTOCOL_ID(0x3,0x3,0,140)
#define CAR_STATUE_Illumination	MAKE_PROTOCOL_ID(0x3,0x4,0,141)
#define CAR_STATUE_SOUND		MAKE_PROTOCOL_ID(0x3,0x5,0,142)
#define CAR_STATUE_GEAR			MAKE_PROTOCOL_ID(0x3,0x6,0,143)
#define CAR_STATUE_GLOBEL		MAKE_PROTOCOL_ID(0x3,0x7,0,144)
#define CAR_STATUE_GO_TO_INFO	MAKE_PROTOCOL_ID(0x3,0x8,0,145)
#define CAR_STATUE_SPEED		MAKE_PROTOCOL_ID(0x3,0x9,0,146)
#define CAR_STATUE_TIME_TO_ACC_OFF	MAKE_PROTOCOL_ID(0x3,0xA,0,147)
#define CAR_STATUE_SAVEDATA 	MAKE_PROTOCOL_ID(0x3,0xB,0,148)
#define CAR_STATUE_CAR_SCREEN_ONOFF	MAKE_PROTOCOL_ID(0x3,0xC,0,149)
#define CAR_STATUE_CAR_POWER_ONOFF	MAKE_PROTOCOL_ID(0x3,0xD,0,150)
#define CarInfoK286Set      MAKE_PROTOCOL_ID(0xc,0x15,0,151)
#define CarInfoK286Notify   MAKE_PROTOCOL_ID(0xc,0x16,0,152)

struct protocol_store_data 
{
	muchar  m_szProtocolData[MAX_RECORD_ITEM][MAX_FRAME_SIZE];
};

template<class _T>
class datatranslater{
public:
	datatranslater(){
		ZeroMemory(m_data,sizeof(m_data));
		m_ndataLen  = 0;
	}
	~datatranslater(){
	}
public:
	_T*  getdata(){
		return m_data;
	}
	int  getdatasize(){
		return m_ndataLen;
	}
	void setdata(_T* pdata,int nlen){
		if (pdata&&nlen>0)
		{
			memcpy(m_data,pdata,nlen*sizeof(TCHAR));
		}
		m_ndataLen = nlen;
	}
protected:
	_T    m_data[MAX_FRAME_SIZE];
	int	  m_ndataLen;
};



#endif //end of __CO_CAR_PROTOCOLDEF_H__