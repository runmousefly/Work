#ifndef __CO_BUSPROTOCOL_API_H__
#define __CO_BUSPROTOCOL_API_H__
/************************************************************************
                                                                      
************************************************************************/
#include "Co_BusProtocol.h"
#ifdef _DEBUG
#define  BUSPROTOCOL_PATH  L"\\NandFlash\\Application\\OriginalCarFun\\Co_BusProtocol_d.dll"
#else
#define  BUSPROTOCOL_PATH  L"\\NandFlash\\Application\\OriginalCarFun\\Co_BusProtocol.dll"
#endif

typedef  LPVOID  (*PFUNCommonLoadfun)();

typedef  Co_BusProtocol* (*PFunCreateBusProtocol)();
#define  NAME_CreateBusProtocol  L"CreateBusProtocol"
typedef  Co_BusHelper*   (*PFunCreateBusHelper)();
#define  NAME_CreateBusHelper  L"CreateBusHelper"
typedef  Co_CarStatue*   (*PFunCreateCarStatue)();
#define  NAME_CreateCarStatue  L"CreateCarStatue"
enum{
	USER_TYPE_BUSPROTOCOL = 0,
	USER_TYPE_BUSHELPER,
	USER_TYPE_CARSTATUE,
};

template <class _T,int g_nType>
class CCo_BusProtocoldllLoader
{
public:
	CCo_BusProtocoldllLoader(){
		hInstance  = NULL;
		m_pclass   = NULL;
	}
	CCo_BusProtocoldllLoader(LPCTSTR lpdllPath){
		hInstance  = NULL;
		m_pclass   = NULL;
		Load(lpdllPath);
	}
	~CCo_BusProtocoldllLoader(){
		UnLoad();
	}
	bool Load(LPCTSTR lpdllPath)
	{
		if (!hInstance){
			hInstance  = ::LoadLibrary(lpdllPath);
			if (hInstance)
			{
				TCHAR szfunname[MAX_PATH] ={0};
				switch(g_nType)
				{
				case USER_TYPE_BUSPROTOCOL:
					{
						wcscpy_s(szfunname,MAX_PATH*sizeof(TCHAR),NAME_CreateBusProtocol);
					}
					break;
				case USER_TYPE_BUSHELPER:
					{
						wcscpy_s(szfunname,MAX_PATH*sizeof(TCHAR),NAME_CreateBusHelper);
					}
					break;
				case USER_TYPE_CARSTATUE:
					{
						wcscpy_s(szfunname,MAX_PATH*sizeof(TCHAR),NAME_CreateCarStatue);
					}
					break;
				}
				PFUNCommonLoadfun pFun =(PFUNCommonLoadfun)GetProcAddress(hInstance,szfunname);
				if (pFun){
					m_pclass = (_T*)pFun();
				}
				if (!getclass()){
					UnLoad();
					return false;
				}
				return true;
			}
			else{
				fwprintf(stderr,L"LoadLibrary() FAILED!!\n",lpdllPath);
			}
		}
		return false;
	}
	void  UnLoad(){
		if (m_pclass)
		{
			m_pclass->uninit();
		}
		if (hInstance)
		{
			::FreeLibrary(hInstance);
		}
	}
	_T*   getclass(){
		return m_pclass;
	}
protected:
	HINSTANCE  hInstance;
	_T*		   m_pclass;	     
};

#endif // end of __CO_BUSPROTOCOL_API_H__